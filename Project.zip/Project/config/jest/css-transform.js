// This is a custom Jest transformer turning style imports into empty objects.
// http://facebook.github.io/jest/docs/en/webpack.html
// https://github.com/facebook/create-react-app/blob/e9abde739240b3124ab7237cbf32a370c209511e/packages/react-scripts/config/jest/cssTransform.js#L14-L22
module.exports = {
  process() {
    return 'module.exports = {};'
  },
  getCacheKey() {
    // The output is always the same.
    return 'cssTransform'
  },
}
