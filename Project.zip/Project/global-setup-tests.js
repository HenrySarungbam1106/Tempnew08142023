import path from 'path'
import { promises as fsPromises } from 'fs'
import { WorldReady, Metadata, LocalProvider } from '@paypalcorp/worldready'

export default async function globalTestSetup() {
  await WorldReady.load(
    new Metadata(),
    new LocalProvider({
      baseDir: path.resolve(__dirname, 'locales'),
      only: ['en-US'],
    }),
  )
  const data = new WorldReady('en-US').export()
  const metadataDir = path.resolve(__dirname, 'node_modules', '.cache')
  try {
    await fsPromises.mkdir(metadataDir, { recursive: true })
    await fsPromises.writeFile(
      path.join(metadataDir, 'worldready-metadata.json'),
      JSON.stringify(data, null, 2),
    )
  } catch (ex) {
    throw new Error(`Error creating workdready metadata ${ex.stack}`)
  }
}
