// We recommend not making custom changes in this file.
// IMPORTANT. Custom configuration should be added in config/next.config[.js/.json]. This way the changes would
//  be available during the build as well as the run.
const defaultConfig = require('./config/next.config.js')
const { apply: applyWebpack } = require('./webpack')
module.exports = applyWebpack({
  ...require('@paypalcorp/paypalize-nextjs').getNextConfig(),
  ...defaultConfig,
})
