const { createServer, logger } = require('@paypalcorp/paypalize-nextjs')
const configClient = require('@paypalcorp/config-client')

const loadUCPConfig = (config) =>
  new Promise((resolve, reject) => {
    configClient.loadConfigurations(config, (err) => {
      if (err) {
        reject(err)
      } else {
        resolve(config)
      }
    })
  })

async function onServer(server) {
  const { port } = server.address()
  const { appConfig: config } = server.framework
  require('servicecore-logger')()
  const address = `http://localhost.paypal.com:${port}${config.get(
    'requestURI',
  )}`
  await loadUCPConfig(config)

  logger.info(
    `[${config.get('env:env').toUpperCase()}] Listening on ${address}`,
  )
}

createServer({ basedir: __dirname }).then(onServer).catch(logger.error)
