##### Unreleased

##### 3.0.3 (June 20 2023)
- Switching to corp SSO
- Checking for user roles
- Displaying merchant email and partner details in F&C section

##### 3.0.2 (April 24 2023)
- Updating SSO keystore

##### 3.0.1 [March 29 2923]
- Fixing an issue with parter permissions details table
- Temporarily disabling extend session functionality due to issues observed in production

##### 3.0.0 [March 28 2023]
- Complete rewrite based on NextJS stack, new UI design
- Use pp-react components
- Add unit test and functional tests