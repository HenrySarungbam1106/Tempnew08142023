import { createContext, useContext, useState } from 'react'
const FormContext = createContext()

// //Hook to use form context
export function useFormData() {
  // console.log('form context is ', useContext(FormContext))
  const { formData, setFormData } = useContext(FormContext)

  const updateFormData = (newData) => {
    return setFormData((previous) => {
      return {
        ...previous,
        ...newData,
      }
    })
  }
  return {
    formData,
    updateFormData,
  }
  //console.log('FormContext is -> ', useContext(formData, setFormData))
  // return useContext(FormContext)
}

//Wrapped form context
export function FormContextProvider({ children }) {
  const [formData, setFormData] = useState({
    from: '',
    to: '',
    accountNumber: '',
    isAccount: null,
    batchMode: false,
    batchAccountData: [],
    error: false,
    message: '',
    batchButtonState: 'initial',
    batchReadState: false,
  })
  //console.log('formData is ', formData)

  return (
    <FormContext.Provider value={{ formData, setFormData }}>
      {children}
    </FormContext.Provider>
  )
}
