import { createContext, useContext, useState } from 'react'
const ServerContext = createContext()

// //Hook to use form context
export function useServerData() {
  // console.log('form context is ', useContext(FormContext))
  const { serverData, setServerData } = useContext(ServerContext)

  const updateServerData = (newData) => {
    return setServerData((previous) => {
      return {
        ...previous,
        ...newData,
      }
    })
  }
  return {
    serverData,
    updateServerData,
  }
  //console.log('FormContext is -> ', useContext(formData, setFormData))
  // return useContext(FormContext)
}

//Wrapped form context
export function ServerContextProvider({ value = {}, children }) {
  const [serverData, setServerData] = useState(value)
  console.log('init value is ', value)
  return (
    <ServerContext.Provider value={{ serverData, setServerData }}>
      {children}
    </ServerContext.Provider>
  )
}
