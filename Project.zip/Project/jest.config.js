const basePathsToIgnore = ['/node_modules/', '/.next/', '/.build/', '/cypress/']

module.exports = {
  collectCoverageFrom: [
    '**/{components,lib,middleware,pages}/**/*.{js,jsx,ts,tsx}',
    '!**/*.d.ts',
    '!.cache/**',
    '!**/__tests__/**',
    '!**/{node_modules,public,.build}/**',
    '!**/components/test/*.{js,jsx,ts,tsx}',
  ],
  coverageThreshold: {
    global: {
      lines: 20,
    },
  },
  coverageReporters: [
    'clover',
    'json',
    'lcov',
    'cobertura',
    'html',
    ['text', { skipFull: true }],
  ],
  coverageDirectory: 'test-results/unit/coverage',
  reporters: [
    'default',
    [
      'jest-junit',
      {
        outputDirectory: 'test-results/unit/',
        outputName: 'junit.xml',
        suiteNameTemplate: '{filepath}',
        classNameTemplate: '{filename}',
        titleTemplate: '{title}',
      },
    ],
  ],
  projects: [
    {
      displayName: 'ui',
      testEnvironment: 'jsdom',
      setupFilesAfterEnv: ['<rootDir>/setup-tests.js'],
      testPathIgnorePatterns: [...basePathsToIgnore, '/lib/', '/pages/api/'],
      transform: {
        '^.+\\.(js|jsx|ts|tsx)$': '<rootDir>/node_modules/babel-jest',
        '^.+\\.css$': '<rootDir>/config/jest/css-transform.js',
      },
      transformIgnorePatterns: [
        // '/node_modules/', // from next.js jest example
        '[/\\\\]node_modules[/\\\\].+\\.(js|jsx|mjs)$', // from paypal-scripts
        '^.+\\.module\\.(css|sass|scss)$',
      ],
      moduleNameMapper: {
        '^.+\\.module\\.(css|sass|scss)$': 'identity-obj-proxy',
      },
      globalSetup: '<rootDir>/global-setup-tests.js',
    },
    {
      displayName: 'server',
      testEnvironment: 'node',
      roots: ['<rootDir>/lib/', '<rootDir>/pages/api/'],
      testPathIgnorePatterns: [...basePathsToIgnore, '/components/'],
      transform: {
        '^.+\\.(js|jsx|ts|tsx)$': '<rootDir>/node_modules/babel-jest',
      },
    },
  ],
}
