const { defineConfig } = require('cypress')
const url =
  process.env.BASE_URL || `http://localhost:8000/merchantintegrationenablement`

module.exports = defineConfig({
  defaultCommandTimeout: 10000,
  chromeWebSecurity: false,
  reporter: 'cypress-multi-reporters',
  reporterOptions: {
    reporterEnabled: 'mochawesome, mocha-junit-reporter',
    mochawesomeReporterOptions: {
      reportDir: 'cypress/reports/mocha',
      overwrite: false,
      html: false,
      json: true,
    },
    mochaJunitReporterReporterOptions: {
      mochaFile: 'cypress/reports/junit/[hash].xml',
    },
  },
  env: {
    codeCoverage: {
      url: `${url}/api/v1/coverage?pp-ft-skipsso=true`,
    },
  },
  watchForFileChanges: false,
  e2e: {
    // We've imported your old cypress plugins here.
    // You may want to clean this up later by importing these.
    setupNodeEvents(on, config) {
      return require('./cypress/plugins/index.js')(on, config)
    },
    baseUrl: 'http://localhost.paypal.com:8000/merchantintegrationenablement',
  },
})
