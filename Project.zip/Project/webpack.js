const WorldReadyWebpackPlugin = require('@paypalcorp/worldready-webpack-plugin')

/* Next.js doesn't allow css imports from 'node_modules' (https://nextjs.org/docs/messages/css-npm). To workaround this restriction, the webpack config below ignores css imports from '@paypalcorp/pp-react' components during both server and client builds. To get '@paypalcorp/pp-react' styles, please import component styles manually.
  Refer: https://github.paypal.com/PayPal-UI-R/pp-react/issues/617
*/
const withTM = require('next-transpile-modules')(['@paypalcorp/pp-react'])

// TODO: move this to a separate module
function apply(nextConfig = {}) {
  function webpack(config, options) {
    const { isServer, webpack } = options
    // const { buildId, dev, isServer, defaultLoaders, webpack } = options;
    // Note: we provide webpack above so you should not `require` it
    // Perform customizations to webpack config
    config.plugins.push(new WorldReadyWebpackPlugin())

    if (!isServer) {
      if (!config.resolve) config.resolve = {}
      if (!config.resolve.fallback) config.resolve.fallback = {}
      Object.assign(config.resolve.fallback, {
        async_hooks: false,
        perf_hooks: false,
        dns: false,
        dgram: false,
        fs: false,
        net: false,
        tls: false,
        child_process: false,
        readline: false,
      })
      // ignore paypalize-nextjs. TODO: This is added for _error.js and should be reviewed
      config.plugins.push(
        new webpack.IgnorePlugin({
          resourceRegExp: /^(@paypalcorp\/paypalize-nextjs)(\/.+)*$/,
        }),
      )
    } else {
      //// Potential workaround if certain CommonJS dependencies are getting compiled as ESM.
      //// Refer https://github.com/vercel/next.js/blob/canary/packages/next/build/webpack-config.ts
      //// This can be used as workaround when dependencies are deployed under nodejs infra bundle and webpack is unable to resolve them
      //// Refer https://paypal.slack.com/archives/G4XTHPP25/p1646872481253139?thread_ts=1646761393.463799&cid=G4XTHPP25
      // const externals = config.externals[0]
      // const commonJsModules = new Set([
      //   'try-require',
      //   'cal',
      //   '@paypalcorp/framework-core',
      //   '@paypalcorp/paypalize-nextjs',
      //   '@paypalcorp/paypalize-nextjs/middleware/locals',
      //   '@paypalcorp/paypalize-nextjs/middleware/nav',
      //   'commonutils-consumer-client',
      //   '@paypalcorp/worldready',
      // ])
      // config.externals = [
      //   async (options) => {
      //     const { request } = options
      //     if (commonJsModules.has(request)) {
      //       // Use commonJS. This is required for suppporting infra dependencies bundle
      //       return 'commonjs ' + request
      //     }
      //     return externals(options)
      //   },
      // ]
    }

    if (typeof nextConfig.webpack === 'function') {
      return nextConfig.webpack(config, options)
    }

    // Important: return the modified config
    return config
  }

  return withTM({ ...nextConfig, webpack })
}

module.exports = {
  apply,
}
