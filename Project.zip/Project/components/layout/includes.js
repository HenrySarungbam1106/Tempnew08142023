import React from 'react'

function Includes({ scripts }) {
  return <div dangerouslySetInnerHTML={{ __html: scripts || '' }} />
}

export default Includes
