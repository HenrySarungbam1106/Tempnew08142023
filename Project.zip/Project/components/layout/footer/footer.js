import styles from './footer.module.scss'

function LayoutFooter({ footerHtml }) {
  console.log('footer HTML is ', footerHtml)
  return (
    <div
      className={styles.footerContainer}
      dangerouslySetInnerHTML={{ __html: footerHtml }}
    />
  )
}

export default LayoutFooter
