import React from 'react'

function LayoutHeader({ desktopHeaderHtml }) {
  return <div dangerouslySetInnerHTML={{ __html: desktopHeaderHtml }} />
}

export default LayoutHeader
