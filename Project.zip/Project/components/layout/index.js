import React from 'react'
import Head from 'next/head'
import Script from 'next/script'
import Header from '../header/header'
import InfoMessage from '../info-message/info-message'
import styles from './index.module.scss'

function Layout({ children, serverData = {}, navSrc = '', nonce = '' }) {
  const {
    cdnHost = 'www.paypalobjects.com',
    firstname = '',
    userEligible,
  } = serverData
  return (
    <>
      <Head>
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />
        <meta name="theme-color" content="#012169" />
        <link
          rel="shortcut icon"
          type="image/x-icon"
          href={`https://${cdnHost}/webstatic/icon/favicon.ico`}
        />
        <link
          rel="icon"
          type="image/x-icon"
          href={`https://${cdnHost}/webstatic/icon/pp32.png`}
        />
        <link rel="dns-prefetch" href={`https://${cdnHost}/`} />
        {/* <!-- Preload font files for better performance --> */}
        <link
          rel="preload"
          as="font"
          type="font/woff2"
          crossOrigin="true"
          href={`https://${cdnHost}/paypal-ui/fonts/PayPalSansBig-Regular.woff2`}
        />
        <link
          rel="preload"
          as="font"
          type="font/woff2"
          crossOrigin="true"
          href={`https://${cdnHost}/paypal-ui/fonts/PayPalSansBig-Medium.woff2`}
        />

        {/* <!-- Font and normalizer necessary for the whole library --> */}
        <link
          rel="stylesheet"
          href={`https://${cdnHost}/paypal-ui/web/fonts-and-normalize/1-1-0/fonts-and-normalize.min.css`}
        />
        <title>Migration Hub</title>
      </Head>

      {/* <main className={styles.main}> */}
      <noscript>You need to enable JavaScript to run this app.</noscript>
      {/* Common PayPal header/footer scripts/style in the "Head" tag causes issues when Next.js reads tags added by it.
      `r.querySelector("meta[name=next-head-count]")` fails. Adding them under "body" tag instead. */}
      <Script src={navSrc} data-country="US" data-language="en" nonce={nonce} />
      {/* <div id="js_foreground" className="vx_foreground-container">
        <div id="contents" className="contents vx_mainContent">  */}
      <div>
        <Header firstname={firstname} />
        {/* <ExtendSession /> */}
        {/* Check if user has the right foles */}
        {!userEligible ? (
          <InfoMessage>
            Please request the following roles via Identity Hub to access this
            app
            <ul>
              <li>
                <b>PP_SSO_MigrationTools_User</b>: Role required to access the
                app
              </li>
              <li>
                <b>PP_SSO_MigrationTools_Class3_Data_Viewer</b>: Role required
                to view any class 3 data returned by the app
              </li>
            </ul>
          </InfoMessage>
        ) : (
          <div id="root">{children}</div>
        )}
        <div className={`merchant-footer ${styles.footer}`}></div>
      </div>
      {/* </main> */}

      {/* <footer className={styles.footer}>
      </footer> */}
    </>
  )
}

export default Layout
