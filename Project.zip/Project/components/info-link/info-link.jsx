import { BodyText, Link } from '@paypalcorp/pp-react'
import styles from './info-link.module.scss'

function InfoLink({
  heading = '',
  text = '',
  link1Text = '',
  link1Target,
  link2Text = '',
  link2Target = '',
}) {
  return (
    <>
      <div>
        <BodyText className={styles.heading} strong>
          {heading}
        </BodyText>
      </div>

      <BodyText className={styles.body}>{text}</BodyText>
      <div className={styles.linkContainer}>
        <Link
          href={link1Target}
          target={link1Target.startsWith('mailto') ? '_self' : '_blank'}
        >
          {link1Text}
        </Link>
        {link2Text && (
          <Link href={link2Target} target="_blank">
            {link2Text}
          </Link>
        )}
      </div>
    </>
  )
}

export default InfoLink
