import AccountDetails from '../account-details/account-details'
// import AccountDetails from '../account-details/account-details-backup'

const MigrationDetails = ({ ucpConfig = {} }) => (
  <>
    {
      //TODO: Move functionality from account details to this component
      //wrap inside config context
      //console.log('UCP config is ', ucpConfig)
    }
    <AccountDetails ucpConfig={ucpConfig} />
  </>
)

export default MigrationDetails
