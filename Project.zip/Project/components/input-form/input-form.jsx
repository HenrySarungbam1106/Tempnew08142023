import { Container, Row, Col, TextInput, Button } from '@paypalcorp/pp-react'
import styles from './input-form.module.scss'
import { useFormData } from '../../context/form-context'
import AccountDropdown from '../account-dropdown/account-dropdown'
import { useRouter } from 'next/router'
import { useServerData } from '../../context/server-context'
import {
  isInputPayerId,
  isInputAccountNumber,
  appendSkipSSO,
} from '../commonutils'
import Notify from '../notify/notify'

function InputForm() {
  const { formData, updateFormData } = useFormData()
  const router = useRouter()
  const { serverData } = useServerData()

  const handleInputChange = (event) => {
    console.log('handle input change called with ', event.target.value)
    const value = event.target.value

    if (isInputPayerId(value)) {
      updateFormData({
        accountNumber: value,
        isAccount: false,
        inputErrorText: '',
      })
    } else if (isInputAccountNumber(value)) {
      updateFormData({
        accountNumber: value,
        isAccount: true,
        inputErrorText: false,
      })
    } else {
      updateFormData({
        accountNumber: '',
        isAccount: null,
        inputErrorText: false,
      })
    }
  }

  const handleSubmit = () => {
    const { accountNumber, isAccount, from, to } = formData
    console.log('accountNumber is ', accountNumber)
    if (!formData.accountNumber || formData.isAccount === null) {
      updateFormData({
        inputErrorText: 'Please enter a valid Account Number or Payer ID',
      })
      return
    }

    let accountURL = `/account?accountNumber=${accountNumber}&isAccount=${isAccount}&migrateFrom=${from.value}&migrateTo=${to.value}`
    // using router.push instead of next/link since it is Submit button action instead of a hyperlink

    if (serverData.skipSSO) {
      accountURL = appendSkipSSO(accountURL)
    }
    console.log('accountURL is ', accountURL)
    return router.push(accountURL)
  }

  return (
    <Container form>
      <Notify />
      <Row className={styles.inputFormRow}>
        <Col form="full">
          <p>Account information and migration path details</p>
          <TextInput
            name="accountNumber"
            value={formData.accountNumber}
            label="Account Number or Payer ID"
            onBlur={handleInputChange}
            errorText={formData.inputErrorText}
          />
        </Col>
      </Row>
      <Row>
        <AccountDropdown />
      </Row>
      <Row>
        <Col align="center" className={styles.buttonContainer}>
          <Button className={styles.button} onClick={handleSubmit}>
            Submit
          </Button>
        </Col>
      </Row>
    </Container>
  )
}

export default InputForm
