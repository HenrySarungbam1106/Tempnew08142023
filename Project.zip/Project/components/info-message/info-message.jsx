import { Alert } from '@paypalcorp/pp-react'
import styles from './info-message.module.scss'

export default function InfoMessage({ children }) {
  return (
    <>
      <Alert className={styles.info} type="info">
        {children}
      </Alert>
    </>
  )
}
