import { fireEvent, render, screen } from '../../test/client-test-utils'
import InputForm from '../../input-form/input-form'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config

describe('input form component', () => {
  test('input form component renders correctly', async () => {
    render(
      <TestContext>
        <InputForm />
      </TestContext>,
    )

    const inputLabel = await screen.findByText(
      'Account information and migration path details',
    )
    expect(inputLabel).toBeInTheDocument()

    const accountInput = screen.getByRole('textbox', {
      name: /account number or payer id/i,
    })

    fireEvent.change(accountInput, { target: { value: '4799480374997464040' } })
    fireEvent.focusOut(accountInput)
    fireEvent.click(screen.getByRole('button', { name: /migrate from/i }))
    fireEvent.click(
      screen.getByRole('option', { name: /website payments standard/i }),
    )

    fireEvent.click(screen.getByRole('button', { name: /migrate to/i }))
    fireEvent.click(
      screen.getByRole('option', { name: /orders v2 with advanced cards/i }),
    )

    fireEvent.click(screen.getByRole('button', { name: /submit/i }))
  })
})
