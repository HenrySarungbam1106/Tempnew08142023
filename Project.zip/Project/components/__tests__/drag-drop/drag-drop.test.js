import { fireEvent, render, screen } from '../../test/client-test-utils'
import DragDrop from '../../drag-drop/drag-drop'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config

describe('drag and drop component', () => {
  test('drag and drop component renders correctly', async () => {
    render(
      <TestContext>
        <DragDrop />
      </TestContext>,
    )

    const dragText = await screen.findByText('Drag and drop or click to browse')
    expect(dragText).toBeInTheDocument()

    const dragDropComponent = screen.getByTestId('drag-drop')
    const dragActiveStyle = { border: '3px dashed black' }
    expect(dragDropComponent).toBeInTheDocument()
    expect(dragDropComponent).not.toHaveStyle(dragActiveStyle)

    fireEvent.dragEnter(dragDropComponent)
    expect(dragDropComponent).toHaveStyle(dragActiveStyle)
    fireEvent.dragLeave(dragDropComponent)
    expect(dragDropComponent).not.toHaveStyle(dragActiveStyle)
  })
})
