import { render, screen, fireEvent } from '../../test/client-test-utils'
import Landing from '../../landing/landing'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config

describe('landing page component', () => {
  test('landing page renders correctly', async () => {
    render(
      <TestContext>
        <Landing />
      </TestContext>,
    )

    const sectionHeading = await screen.findByText('Migration Readiness Search')
    expect(sectionHeading).toBeInTheDocument()
  })

  test('switch to batch component', async () => {
    render(
      <TestContext>
        <Landing />
      </TestContext>,
    )

    const batchUploadButton = screen.getByRole('tab', {
      name: /Batch upload/i,
    })

    fireEvent.click(batchUploadButton)
    const batchUploadText = await screen.findByText(
      'Drag and drop or click to browse',
    )
    expect(batchUploadText).toBeInTheDocument()
  })
})
