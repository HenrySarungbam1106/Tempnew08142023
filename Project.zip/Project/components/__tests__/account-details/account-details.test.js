import { useRouter } from 'next/router'
import { render, screen, fireEvent } from '../../test/client-test-utils'
import AccountDetails from '../../account-details/account-details'
import TestContext from '../../test/context'
import fetchMock from 'jest-fetch-mock'
import mockAccountResponse from './mock-response.json'
import config from '../../../config/config.json'
import '../../test/jest.setup' //required for hydrating worldready config

jest.mock('next/router', () => ({
  useRouter: jest.fn(),
}))

describe('account details page', () => {
  beforeAll(() => {
    useRouter.mockImplementation(() => ({
      push: jest.fn(),
      pathname: '',
      route: '',
      asPath: '',
      query: {
        accountNumber: '4799480374997464040',
        isAccount: true,
        migrateFrom: 'PRO_3_0',
        migrateTo: 'ORDERS_V2_ACDC',
      },
    }))
  })

  beforeEach(() => {
    fetchMock.resetMocks()
    fetchMock.enableMocks()
  })

  test('render account features and capabilities', async () => {
    fetchMock.mockResponseOnce(JSON.stringify(mockAccountResponse.success))

    render(
      <TestContext>
        <AccountDetails ucpConfig={config.appconfig} />
      </TestContext>,
    )

    expect(fetchMock.mock.calls.length).toEqual(1)

    const accountName = await screen.findByDisplayValue(/Gourmet Burgers/i)
    const countryCode = await screen.findByDisplayValue('US')
    screen.debug()
    const primaryCurrency = await screen.findByDisplayValue(/USD/i)
    const holdingCurrency = await screen.findByDisplayValue(/MXN/i)
    const virtualTerminal = await screen.findByDisplayValue(/NOT_SUBSCRIBED/i)
    const refTransactions = await screen.findByDisplayValue(/NOT_ACTIVE/)
    const link = await screen.findByDisplayValue('4799480374997464040')

    expect(accountName).toBeInTheDocument()
    expect(countryCode).toBeInTheDocument()
    expect(primaryCurrency).toBeInTheDocument()
    expect(holdingCurrency).toBeInTheDocument()
    expect(virtualTerminal).toBeInTheDocument()
    expect(refTransactions).toBeInTheDocument()
    expect(link).toBeInTheDocument()
  })

  test('render evaluation checks', async () => {
    fetchMock.mockResponseOnce(JSON.stringify(mockAccountResponse.success))

    render(
      <TestContext>
        <AccountDetails />
      </TestContext>,
    )

    expect(fetchMock.mock.calls.length).toEqual(1)

    //once first evaluation is available, it should be safe to assume others are available as well
    const bo = await screen.findAllByText('Beneficial Owner')

    const compliance = screen.getAllByText('Compliance - CIP')
    const ppcp = screen.getAllByText('PPCP Custom')
    const partnerPerms = screen.getAllByText('Partner Permissions')
    const billing = screen.getAllByText('Recurring Billing')
    const accountStatus = screen.getAllByText('Account Status')
    const reporting = screen.getAllByText('Reporting')
    const pricing = screen.getAllByText('Pricing')
    const accountPricing = screen.getAllByText('Account Pricing')

    const successfulChecks = screen.getAllByText('SUCCESS')
    const warningChecks = screen.getAllByText('WARNING')
    const errorChecks = screen.getAllByText('ERROR')

    expect(bo.length).toEqual(2)
    expect(compliance.length).toEqual(2)
    expect(ppcp.length).toEqual(2)
    expect(partnerPerms.length).toEqual(2)
    expect(billing.length).toEqual(2)
    expect(accountStatus.length).toEqual(2)
    expect(reporting.length).toEqual(2)
    expect(pricing.length).toEqual(2)
    expect(accountPricing.length).toEqual(2)

    expect(successfulChecks.length).toEqual(4)
    expect(warningChecks.length).toEqual(4)
    expect(errorChecks.length).toEqual(1)

    const showDetails = screen.getByRole('button', { name: /show details/i })
    fireEvent.click(showDetails)

    const hideDetails = screen.getByRole('button', { name: /hide details/i })

    expect(hideDetails).toBeInTheDocument()

    expect(
      screen.getByRole('columnheader', { name: /product name/i }),
    ).toBeInTheDocument()
    expect(
      screen.getByRole('columnheader', { name: /product category/i }),
    ).toBeInTheDocument()
    expect(
      screen.getByRole('columnheader', { name: /price/i }),
    ).toBeInTheDocument()

    expect(
      screen.getByRole('cell', { name: /basic_virtual_terminal/i }),
    ).toBeInTheDocument()
  })

  test('show error message in case of failure', async () => {
    fetchMock.mockRejectOnce(new Error('Internal server error'))
    render(
      <TestContext>
        <AccountDetails />
      </TestContext>,
    )

    expect(fetchMock.mock.calls.length).toEqual(1)

    const errorAlert = await screen.findByRole('alert', {
      name: /response alert/i,
    })
    expect(errorAlert).toBeInTheDocument()
  })
})
