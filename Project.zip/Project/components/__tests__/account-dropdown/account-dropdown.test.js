import { render, screen } from '../../test/client-test-utils'
import AccountDropdown from '../../account-dropdown/account-dropdown'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config

describe('account dropdown component', () => {
  test('rendering account dropdown component', async () => {
    render(
      <TestContext>
        <AccountDropdown />
      </TestContext>,
    )

    const migrateFromLabel = await screen.findByLabelText(/Migrate From/i)
    const migrateToLabel = await screen.findByLabelText(/Migrate To/i)

    expect(migrateFromLabel).toBeInTheDocument()
    expect(migrateToLabel).toBeInTheDocument()
  })
})
