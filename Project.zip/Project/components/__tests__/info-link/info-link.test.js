import { render, screen } from '../../test/client-test-utils'
import InfoLink from '../../info-link/info-link'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config

describe('info link component', () => {
  test('info links render correctly', async () => {
    render(
      <TestContext>
        <InfoLink
          heading="Sample heading"
          text="Sample description"
          link1Text="Link 1"
          link1Target="www.paypal.com"
        />
      </TestContext>,
    )

    const infoHeading = await screen.findByText('Sample heading')
    expect(infoHeading).toBeInTheDocument()
  })
})
