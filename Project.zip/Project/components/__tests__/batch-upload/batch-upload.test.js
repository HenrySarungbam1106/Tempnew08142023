import { render, screen, fireEvent } from '../../test/client-test-utils'
import BatchUpload from '../../batch-upload/batch-upload'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config
import fs from 'fs'
import path from 'path'
import fetchMock from 'jest-fetch-mock'
import mockBatchUploadResponse from './mock-reponse.json'

describe('batch upload component', () => {
  beforeEach(() => {
    fetchMock.resetMocks()
    fetchMock.enableMocks()
  })

  test('batch upload component renders correctly', async () => {
    render(
      <TestContext>
        <BatchUpload />
      </TestContext>,
    )
    const uploadText = await screen.findByText(
      'Upload a CSV file containing account numbers or payer IDs',
    )
    expect(uploadText).toBeInTheDocument()
  })

  test('drag and drop event - xls file', async () => {
    render(
      <TestContext>
        <BatchUpload />
      </TestContext>,
    )
    const uploadText = await screen.findByText(
      'Upload a CSV file containing account numbers or payer IDs',
    )

    expect(uploadText).toBeInTheDocument()

    const fileBuffer = fs.readFileSync(
      path.join(__dirname, 'sample.xlsx'),
    ).buffer
    const xlsFileObj = new File([fileBuffer], 'sample.xlsx', {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    })

    fireEvent.drop(screen.getByText(/Drag and drop or click to browse/i), {
      dataTransfer: {
        files: [xlsFileObj],
      },
    })

    const accountText = await screen.findByText(/JFJB8J699Q5UA/i)
    expect(accountText).toBeInTheDocument()
  })

  test('drag and drop txt file with submit', async () => {
    fetchMock.mockResponseOnce(JSON.stringify(mockBatchUploadResponse.success))

    render(
      <TestContext>
        <BatchUpload />
      </TestContext>,
    )
    const uploadText = await screen.findByText(
      'Upload a CSV file containing account numbers or payer IDs',
    )

    expect(uploadText).toBeInTheDocument()

    fireEvent.drop(screen.getByText(/Drag and drop or click to browse/i), {
      dataTransfer: {
        files: [
          new File(['1774789437047491770'], 'foo.txt', { type: 'text/plain' }),
        ],
      },
    })

    const accountText = await screen.findByText(/1774789437047491770/i)
    expect(accountText).toBeInTheDocument()

    const submitButton = screen.getByRole('button', { name: 'Submit' })
    fireEvent.click(submitButton)

    expect(fetchMock.mock.calls.length).toEqual(1)

    const batchId = await screen.findByText(/120083239737250907/i)
    expect(batchId).toBeInTheDocument()
  })

  test('click to upload - xls file', async () => {
    render(
      <TestContext>
        <BatchUpload />
      </TestContext>,
    )

    const fileBuffer = fs.readFileSync(
      path.join(__dirname, 'sample.xlsx'),
    ).buffer
    const xlsFileObj = new File([fileBuffer], 'sample.xlsx', {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    })

    fireEvent.change(screen.getByTestId('file-upload'), {
      target: { files: [xlsFileObj] },
    })

    const accountText = await screen.findByText(/JFJB8J699Q5UA/i)
    expect(accountText).toBeInTheDocument()
  })

  test('drag and drop png file', async () => {
    render(
      <TestContext>
        <BatchUpload />
      </TestContext>,
    )

    fireEvent.drop(screen.getByText(/Drag and drop or click to browse/i), {
      dataTransfer: {
        files: [new File(['sample image'], 'abc.png', { type: 'image/x-png' })],
      },
    })
    const errorText = await screen.findByText(
      /Only xls,txt,xlsx,csv file formats are acceptable/i,
    )
    expect(errorText).toBeInTheDocument()
  })
})

test('error calling batch upload API', async () => {
  fetchMock.mockReject(new Error('Network error.'))
  render(
    <TestContext>
      <BatchUpload />
    </TestContext>,
  )
  const uploadText = await screen.findByText(
    'Upload a CSV file containing account numbers or payer IDs',
  )

  expect(uploadText).toBeInTheDocument()

  fireEvent.drop(screen.getByText(/Drag and drop or click to browse/i), {
    dataTransfer: {
      files: [
        new File(['1774789437047491770'], 'foo.txt', { type: 'text/plain' }),
      ],
    },
  })

  const accountText = await screen.findByText(/1774789437047491770/i)
  expect(accountText).toBeInTheDocument()

  const submitButton = screen.getByRole('button', { name: 'Submit' })
  fireEvent.click(submitButton)

  expect(fetchMock.mock.calls.length).toEqual(1)

  const errorMessage = await screen.findByText(
    /Please try again in a few minutes./i,
  )
  expect(errorMessage).toBeInTheDocument()
})
