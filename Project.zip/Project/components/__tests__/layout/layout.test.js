import { render, screen } from '../../test/client-test-utils'
import Layout from '../../layout/index'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config

describe('layout component', () => {
  test('rendering layout component', async () => {
    const { container } = render(
      <TestContext>
        <Layout
          navSrc="https://www.paypalobjects.com/merchant-hf/latest/hf.js"
          nonce="O92ROT6lFj2QdoUkBtgmGVUIsKjaeJc93zT3yfKZhR3v+1ql"
        />
      </TestContext>,
    )

    const migrationHubHeading = await screen.getByRole('heading', {
      name: /migration hub/i,
    })
    expect(migrationHubHeading).toBeInTheDocument()

    expect(container.getElementsByClassName('merchant-footer').length).toBe(1)
  })
})
