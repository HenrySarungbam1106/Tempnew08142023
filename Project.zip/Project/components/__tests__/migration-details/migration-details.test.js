import MigrationDetails from '../../migration-details/migration-details'
import TestContext from '../../test/context'
import config from '../../../config/config.json'
import { useRouter } from 'next/router'
import { render, screen } from '../../test/client-test-utils'

jest.mock('next/router', () => ({
  useRouter: jest.fn(),
}))

describe('account details page', () => {
  beforeAll(() => {
    useRouter.mockImplementation(() => ({
      push: jest.fn(),
      pathname: '',
      route: '',
      asPath: '',
      query: {
        accountNumber: '4799480374997464040',
        isAccount: true,
        migrateFrom: 'PRO_3_0',
        migrateTo: 'ORDERS_V2_ACDC',
      },
    }))
  })

  test('render migration details component', async () => {
    render(
      <TestContext>
        <MigrationDetails ucpConfig={config.appconfig} />
      </TestContext>,
    )

    const detailsText = await screen.findByText('Migration Readiness Details')
    expect(detailsText).toBeInTheDocument()
  })
})
