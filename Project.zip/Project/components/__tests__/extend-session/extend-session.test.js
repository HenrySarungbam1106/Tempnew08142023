import {
  fireEvent,
  render,
  screen,
  waitFor,
} from '../../test/client-test-utils'
import ExtendSession from '../../extend-session/extend-session'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config
import fetchMock from 'jest-fetch-mock'

describe('extend session component', () => {
  beforeEach(() => {
    fetchMock.resetMocks()
    fetchMock.enableMocks()
  })

  test('extend session component should popup after configured timeout', async () => {
    fetchMock.mockResponseOnce(JSON.stringify({}))

    render(
      <TestContext>
        <ExtendSession />
      </TestContext>,
    )

    let extendSessionPopup = screen.queryByTestId('animator')
    expect(extendSessionPopup).not.toBeInTheDocument()

    // screen.debug()
    extendSessionPopup = await screen.findByTestId(
      'animator',
      {},
      { timeout: 10000 },
    )
    expect(extendSessionPopup).toBeInTheDocument()

    const loggedInButton = screen.getByRole('button', {
      name: /stay logged in/i,
      hidden: true,
    })
    expect(loggedInButton).toBeInTheDocument()

    fireEvent.click(loggedInButton)
    await waitFor(() => {
      expect(screen.queryByTestId('animator')).not.toBeInTheDocument()
      expect(fetchMock.mock.calls.length).toEqual(1)
    })
  }, 10000)
})
