import { render, screen } from '../../test/client-test-utils'
import Header from '../../header/header'
import TestContext from '../../test/context'
import '../../test/jest.setup' //required for hydrating worldready config

describe('header component', () => {
  test('header component renders correctly', async () => {
    render(
      <TestContext>
        <Header />
      </TestContext>,
    )

    const logoText = await screen.findByText('Migration Hub')
    expect(logoText).toBeInTheDocument()
  })
})
