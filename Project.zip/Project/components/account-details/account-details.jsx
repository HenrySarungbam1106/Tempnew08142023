import {
  TextDisplay,
  Row,
  Col,
  BodyText,
  Container,
  HeadingText,
  LoadingSpinner,
  Divider,
  CriticalSmIcon,
  CheckmarkBackgroundSmIcon,
  ListSimpleIcon,
  DeclineIcon,
  Tooltip,
  Link,
  ShareIcon,
} from '@paypalcorp/pp-react'
import React from 'react'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import { useServerData } from '../../context/server-context'
import { getSummary } from './utils'
import EvaluationCard from '../evaluation-card/evaluation-card'
import FilterButton from '../filter-button/filter-button'

import styles from './account-details.module.scss'
import BreadCrumb from '../breadcrumb/breadcrumb'
import { useFormData } from '../../context/form-context'
import { appendSkipSSO } from '../commonutils'
import { resolveAPIName } from '../commonutils'
import Notify from '../notify/notify'

const statusMap = {
  ALL: {
    name: 'ALL',
    displayName: 'All',
    icon: ListSimpleIcon,
  },
  SUCCESS: {
    name: 'SUCCESS', //name corresponds to evaluation status returned by the backend
    displayName: 'Success',
    icon: CheckmarkBackgroundSmIcon,
  },
  WARNING: {
    name: 'WARNING',
    displayName: 'Warning',
    icon: CriticalSmIcon,
  },
  ERROR: {
    name: 'ERROR',
    displayName: 'Error',
    icon: DeclineIcon,
  },
}

const AccountDetails = ({ ucpConfig = {} }) => {
  const { formData, updateFormData } = useFormData()
  const router = useRouter()
  const { serverData } = useServerData()
  const [accountFeatures, setAccountFeatures] = useState({})
  const [requirements, setRequirements] = useState([])
  const [accountNum, setAccountNum] = useState()
  const [filter, setFilter] = useState({
    [statusMap.SUCCESS.name]: 0,
    [statusMap.WARNING.name]: 0,
    [statusMap.ERROR.name]: 0,
    [statusMap.ALL.name]: 0,
    type: statusMap.ALL.name,
  })
  const [isLoading, setIsLoading] = useState(false)
  console.log('account details server data is ', serverData)
  console.log('account features are ', accountFeatures)

  const safeParse = (data) => {
    let result = null
    try {
      result = JSON.parse(data)
    } catch (err) {
      console.error('Unable to parse JSON data', data)
    }
    return result
  }

  const handleFilterClick = (name) => {
    if (name) {
      setFilter((prev) => ({
        ...prev,
        type: name,
      }))
    }
  }

  useEffect(async () => {
    const { accountNumber, isAccount, migrateFrom, migrateTo } =
      router.query ?? {}
    console.log('query data is ', {
      accountNumber,
      isAccount,
      migrateFrom,
      migrateTo,
    })

    if (accountNumber && migrateFrom && migrateTo && isAccount) {
      try {
        setIsLoading(true)
        let serverURL = `${serverData.requestURI}/api/v1/evaluations`
        if (serverData.skipSSO) {
          serverURL = appendSkipSSO(serverURL)
        }
        const response = await fetch(serverURL, {
          method: 'POST',
          body: JSON.stringify({
            account_number: accountNumber,
            current_integration: migrateFrom,
            new_integration: migrateTo,
            is_account_number: isAccount === 'true' ? true : false,
          }),
          headers: {
            'x-csrf-token': serverData._csrf,
            'Content-Type': 'application/json',
          },
        })
        const responseJSON = await response.json()

        if (!response.ok) {
          throw new Error(`${response.status}: ${responseJSON.message}`)
        } else {
          setIsLoading(false)
          setAccountNum(responseJSON?.account_number ?? '')
          setRequirements(responseJSON?.evaluations ?? [])
        }
      } catch (err) {
        console.error('ERROR calling API call', err.message)
        setIsLoading(false)
        updateFormData({
          error: true,
          message: `${err.message} Please try again in a few minutes.`,
        })
      }
    } else {
      //redirecting user to home page as required parameters are not present
      console.log('redirecting user')
      router.push(`/`)
    }
  }, [])

  const link = () => (
    <div className={styles.rowTips}>
      <div dir="rtl">
        <Link
          href={`https://engineering.paypalcorp.com/merchantmonitor/#/api-activity/results?openTab=api-table&idType=accountId&idValue=${accountNum}&idActor=1`}
          target="_blank"
          leftIcon={<ShareIcon size="sm" />}
        >
          Link
        </Link>
      </div>
      <Tooltip className={styles.tooltipIcon}></Tooltip>
    </div>
  )

  useEffect(() => {
    let accountName,
      countryCode,
      primaryCurrency,
      holdingCurrency,
      virtualTerminal,
      recurringBilling,
      markReferenceTransaction,
      successCount = 0,
      warningCount = 0,
      errorCount = 0,
      primaryEmail,
      accountManagerEmail,
      accountManagerName,
      allCount = requirements?.length

    let accountStatusFound = false
    for (let x = 0; x < requirements.length; x++) {
      const evaluation = requirements[x]
      if (!accountStatusFound) {
        if (evaluation.evaluation_name === 'ACCOUNT_STATUS') {
          // Object destructuring is not used here due to a bug in prettier which was unneccessarily adding
          // a semicolon in front when using object destructuing
          // https://github.com/prettier/prettier-vscode/issues/2507
          countryCode = evaluation.country_code
          accountName = evaluation.account_name
          primaryCurrency = evaluation.primary_currency
          holdingCurrency = evaluation.holding_currency
          virtualTerminal = evaluation.virtual_terminal
          markReferenceTransaction = evaluation.mark_reference_transaction
          primaryEmail = evaluation.primary_email
          accountManagerName = evaluation.account_manager_name
          accountManagerEmail = evaluation.account_manager_email
          accountStatusFound = true
        }
      }
      if (evaluation.status === statusMap.SUCCESS.name) {
        successCount++
      } else if (evaluation.status === statusMap.WARNING.name) {
        warningCount++
      } else {
        errorCount++
      }
    }

    console.log('setting account features', {
      accountName,
      countryCode,
      primaryCurrency,
      holdingCurrency,
      virtualTerminal,
      markReferenceTransaction,
      recurringBilling,
      primaryEmail,
      accountManagerName,
      accountManagerEmail,
    })
    setAccountFeatures({
      accountName,
      countryCode,
      primaryCurrency,
      holdingCurrency,
      virtualTerminal,
      markReferenceTransaction,
      recurringBilling,
      primaryEmail,
      accountManagerName,
      accountManagerEmail,
    })

    setFilter((prev) => ({
      ...prev,
      [statusMap.SUCCESS.name]: successCount,
      [statusMap.WARNING.name]: warningCount,
      [statusMap.ERROR.name]: errorCount,
      [statusMap.ALL.name]: allCount,
    }))
  }, [requirements])

  const numericStatus = (status = statusMap.SUCCESS.name) => {
    if (status === statusMap.SUCCESS.name) return 0
    if (status === statusMap.WARNING.name) return 1
    return 2
  }

  const bubbleUpWarnings = (eval1 = {}, eval2 = {}) =>
    numericStatus(eval2.status) - numericStatus(eval1.status)

  return (
    <>
      {console.log('ucp config is ', ucpConfig)}
      {console.log('requirements are ', requirements)}
      {console.log('account features are ', accountFeatures)}
      {console.log('filters are ', filter)}

      <BreadCrumb></BreadCrumb>

      <Container className={styles.container}>
        <div>
          <Row>
            <Col className={styles.containerTopCol}>
              <HeadingText size="sm" className={styles.heading}>
                Migration Readiness Details
              </HeadingText>
            </Col>
          </Row>
          <Notify />
          <Row className={styles.containerBottomRow}>
            <BodyText strong>Account Information and Migration path</BodyText>
          </Row>

          {/* <Card style={{
        marginTop: '1rem',
        marginLeft: '-1rem'

      }}> */}

          <Row className={styles.detailsContainer} style={{}}>
            {Object.entries({
              'Account number or Payer ID': router.query.accountNumber,
              'Migrate from':
                router.from?.primaryText ??
                resolveAPIName(router.query.migrateFrom)?.primaryText ??
                'UNDEFINED',
              'Migrate to':
                formData.to?.primaryText ??
                resolveAPIName(router.query.migrateTo)?.primaryText ??
                'UNDEFINED',
            }).map(([key, value]) =>
              value ? (
                <Col
                  key={key}
                  lg={4}
                  md={4}
                  sm={6}
                  className={styles.detailsElement}
                >
                  <TextDisplay name={key} label={key} value={value} />
                </Col>
              ) : (
                ''
              ),
            )}
            {/* <Col lg={1} md={1} sm={2} className={ styles.detailsElement }>
<Button tertiary iconComponent={EditIcon}>
      
    </Button>
    </Col> */}
          </Row>

          <Row className={styles.detailsContainerRow}>
            <BodyText strong>Account details</BodyText>
          </Row>

          {/* <Card style={{
        marginTop: '1rem',
        marginLeft: '-1rem'

      }}> */}

          <Row className={styles.detailsContainer} style={{}}>
            {isLoading ? (
              // <Col text-align='center'>
              <LoadingSpinner screenReaderText="loading" />
            ) : (
              // </Col>
              Object.entries({
                'Account Name: ': accountFeatures.accountName,
                'Country Code: ': accountFeatures.countryCode,
                'Primary Currency: ': accountFeatures.primaryCurrency,
                'Holding Currency: ': accountFeatures.holdingCurrency,
                'Primary Email': accountFeatures.primaryEmail,
                'Account Manager Name': accountFeatures.accountManagerName,
                'Account Manager Email': accountFeatures.accountManagerEmail,
                'Virtual Terminal: ': accountFeatures.virtualTerminal,
                'Reference Transactions: ':
                  accountFeatures.markReferenceTransaction,
                'API usage': link(),
              }).map(([key, value]) =>
                value ? (
                  <Col
                    key={key}
                    lg={3}
                    md={4}
                    sm={6}
                    className={styles.detailsElement}
                  >
                    <TextDisplay name={key} label={key} value={value} />
                  </Col>
                ) : (
                  ''
                ),
              )
            )}
          </Row>

          {/* </Card> */}

          <Row className={styles.detailsContainerBottomRow}>
            {/* <Col> */}
            <BodyText strong className={styles.bodytextContainer}>
              Evaluations {console.log('filter is ', filter)}
              {Object.values(statusMap).map(({ name, displayName, icon }) => (
                <FilterButton
                  key={name}
                  name={name}
                  displayName={displayName}
                  icon={icon}
                  count={filter?.[name]}
                  onClick={handleFilterClick}
                  secondary={filter.type === name ? false : true}
                ></FilterButton>
              ))}
              {/* <FilterButton
                        key={status}
                        name={status}
                        count={filter?.[status?.toLowerCase()]}
    
                        onClick={handleFilterClick}
                      ></FilterButton>
                ))} */}
              {/* <Button size="sm" style={{ marginLeft: '1rem' }} iconComponent={CheckmarkBackgroundSmIcon} secondary>
                Success (4)
              </Button>
              <Button size="sm" style={{ marginLeft: '1rem' }} iconComponent={CriticalSmIcon} secondary>
                Warning (5)
              </Button> */}
            </BodyText>

            {/* </Col> */}
          </Row>
          {/* <Row style={{
          marginTop: "0.75rem",
          marginBottom: "0.75rem"
        }}>
        <Button tertiary style={{marginTop: "-0.5rem", marginLeft: "20rem"}}>All checks (9)</Button>
            <Button tertiary style={{marginTop: "-0.5rem", marginLeft: "1rem"}}>Passed (5)</Button>
            <Button tertiary style={{marginTop: "-0.5rem", marginLeft: "1rem"}}>Failed (4)</Button> 
        </Row>
        <Divider/> */}

          <Row className={styles.readinessReport}>
            {isLoading ? (
              <LoadingSpinner screenReaderText="loading-report" />
            ) : (
              <Col className={styles.readinessReportCol}>
                {/* <Row>
                  <Col
                    style={{
                      display: 'flex',
                      // justifyContent: 'center',
                    }}
                  >
                    <div><div>Overall recommendation: </div><CriticalSmIcon/></div>
                    <FilterButton key='all' name='All checks' count={requirements.length} onClick={handleFilterClick}></FilterButton>
                    {['success', 'warning', 'error'].map(status => (
                      <FilterButton
                        key={status}
                        name={status}
                        count={filter?.[status]}
                        onClick={handleFilterClick}
                      ></FilterButton>
                    ))}
                  </Col>
                </Row> */}
                {/* <Divider/> */}
                {requirements
                  .sort(bubbleUpWarnings)
                  .filter(
                    (evaluation) =>
                      filter.type === statusMap.ALL.name ||
                      filter.type === evaluation.status,
                  )
                  .map((evaluation) => {
                    const {
                      display_name,
                      status,
                      description,
                      evaluation_name,
                    } = evaluation
                    const config = ucpConfig?.components?.[evaluation_name]
                    const summary = getSummary(config, evaluation)
                    let data

                    console.log('evaluation is ', evaluation)

                    if (
                      evaluation_name === 'ACCOUNT_PRICING' &&
                      status === 'WARNING'
                    ) {
                      data = safeParse(evaluation.products)
                    } else if (
                      evaluation_name === 'PARTNER_PERMISSIONS' &&
                      status === 'WARNING'
                    ) {
                      data = safeParse(evaluation.permissions)
                    }

                    console.log('data is ', {
                      display_name,
                      evaluation_name,
                      status,
                      description,
                      data,
                    })
                    return (
                      <div key={display_name} data-testid={display_name}>
                        <EvaluationCard
                          displayName={display_name}
                          name={evaluation_name}
                          status={status}
                          summary={summary}
                          data={data}
                          description={description}
                        ></EvaluationCard>
                        <Divider className={styles.dividerDisplayName} />
                      </div>
                    )
                  })}
              </Col>
            )}
          </Row>
        </div>
      </Container>
    </>
  )
}

export default AccountDetails
