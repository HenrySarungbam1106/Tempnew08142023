/* eslint no-template-curly-in-string: 0 */

export const getSummary = (config = {}, evaluation) => {
  console.log('config is ', config)
  const { description: responseDescription = '', evaluation_name = '' } =
    evaluation
  const status = evaluation.status?.toLowerCase() ?? ''
  const configDescription =
    config?.status?.[status]?.message ?? config?.status?.[status] //configs which have sub_status
  let resolvedDescription = configDescription

  if (configDescription) {
    switch (evaluation_name) {
      case 'REPORTING':
        resolvedDescription = configDescription.replace(
          '${REPORT_COUNT}',
          evaluation.report_count || 0,
        )
        break
      case 'PRICING':
        resolvedDescription = configDescription.replace(
          '${PRICING_CATEGORY}',
          evaluation.category_code || '10A',
        )
        break
      case 'ACCOUNT_STATUS':
        if (evaluation?.account_status === 'CLOSED') {
          resolvedDescription =
            'Account is closed. Account may not be upgraded.'
        } else if (evaluation?.account_status === 'INVALID') {
          resolvedDescription = 'Account Number is not valid.'
        } else if (configDescription.sub_status[evaluation.account_status]) {
          resolvedDescription =
            configDescription.sub_status[evaluation.account_status]?.message ||
            '' +
              configDescription.sub_status[evaluation.account_status]
                ?.bank_status?.[evaluation.bank_status]?.message ||
            '' +
              configDescription.sub_status[evaluation.account_status]
                ?.email_status?.[evaluation.email_status]?.message ||
            ''
        } else {
          resolvedDescription = configDescription.sub_status.DEFAULT.message
        }
        break
      case 'COMPLIANCE':
        if (configDescription.sub_status[evaluation.compliance_status]) {
          resolvedDescription = configDescription.sub_status[
            evaluation.compliance_status
          ].message.replace('${JURISDICTION}', evaluation.jurisdiction)
        } else {
          resolvedDescription = configDescription.sub_status.DEFAULT.message
        }
        break
      case 'PPCP_CUSTOM':
        if (configDescription.sub_status[evaluation.subscription_status]) {
          resolvedDescription = configDescription.sub_status[
            evaluation.subscription_status
          ].message.replace(
            '${UPDATE_TIME}',
            evaluation.update_time?.split('T')[0],
          )
        } else {
          resolvedDescription = configDescription.sub_status.DEFAULT.message
        }
        break
      case 'BO':
        if (
          evaluation.account_tier &&
          evaluation.account_tier.match(/PERSONAL|PREMIER/)
        ) {
          resolvedDescription = `${configDescription.slice(0, -1)} as this is ${
            evaluation.account_tier
          } account.`
        }
        break
      default:
        break
    }
  } else {
    resolvedDescription = responseDescription
  }
  return resolvedDescription
}
