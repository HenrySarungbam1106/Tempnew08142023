import { Container, Row, Col, Button } from '@paypalcorp/pp-react'
import AccountDropdown from '../account-dropdown/account-dropdown'
// import AccountTable from '../account-table/account-table'
import styles from './batch-upload.module.scss'
import DragDropContainer from '../drag-drop/drag-drop'
import { useFormData } from '../../context/form-context'
import AccountTable from '../account-table/account-table'
import { useServerData } from '../../context/server-context'
import Notify from '../notify/notify'
import { appendSkipSSO } from '../commonutils'

function BatchUpload() {
  const { serverData } = useServerData()
  const handleSubmit = async () => {
    if (
      Array.isArray(formData.batchAccountNumbers) &&
      formData.batchAccountNumbers.length > 0
    ) {
      console.log('form data account numbers is ', {
        batchAccount: formData.batchAccountNumbers,
        from: formData.from.value,
        to: formData.to.value,
      })

      const batchEvaluationArray = formData.batchAccountNumbers.map(
        ({ number, isPayerId }) => {
          const key = isPayerId ? 'payer_id' : 'account_number'
          return {
            [key]: number,
            current_integration: formData.from.value,
            new_integration: formData.to.value,
            evaluation_name: '',
          }
        },
      )

      console.log('batch evaluation array is ', batchEvaluationArray)

      try {
        updateFormData({
          batchButtonState: 'processing',
        })

        let serverURL = `${serverData.requestURI}/api/v1/evaluations-batch`

        if (serverData.skipSSO) {
          serverURL = appendSkipSSO(serverURL)
        }

        const response = await fetch(serverURL, {
          method: 'POST',
          body: JSON.stringify({
            items: batchEvaluationArray,
          }),
          headers: {
            'x-csrf-token': serverData._csrf,
            'Content-Type': 'application/json',
          },
        })

        console.log('response.body is ', response.body)
        const responseJSON = await response.json()

        if (!response.ok) {
          throw new Error(`${response.status}: ${responseJSON.message}`)
        } else {
          updateFormData({
            message: `Batch request submitted successfully.\n Once processing is complete, you will receive an email with the report. Batch ID: ${responseJSON.id}`,
            error: false,
            batchAccountNumbers: [],
            batchButtonState: 'initial',
          })
        }
      } catch (err) {
        console.error('ERROR calling batch API', err)
        updateFormData({
          message: `${err.message} Please try again in a few minutes.`,
          error: true,
          batchButtonState: 'initial',
        })
      }
    } else {
      updateFormData({
        message: 'Please upload a file',
        error: true,
        batchButtonState: 'initial',
      })
    }
  }

  const { formData, updateFormData } = useFormData()
  return (
    <Container form className={styles.form}>
      <Notify />
      <Row className={styles.containerRow}>
        <Col form="full" align="center">
          {formData.batchAccountNumbers &&
          formData.batchAccountNumbers.length > 0 ? (
            <AccountTable />
          ) : (
            <DragDropContainer />
          )}
        </Col>
      </Row>
      <Row className={styles.containerRow}>
        <AccountDropdown />
      </Row>
      <Row>
        <Col align="center" className={styles.buttonContainer}>
          <Button
            className={styles.button}
            onClick={handleSubmit}
            btnState={formData.batchButtonState}
          >
            Submit
          </Button>
        </Col>
      </Row>
    </Container>
  )
}

export default BatchUpload
