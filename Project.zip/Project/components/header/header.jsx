import styles from './header.module.scss'
import Image from 'next/image'
import Link from 'next/link'
import {
  InformationIcon,
  GetDirectionsIcon,
  ContactUsIcon,
} from '@paypalcorp/pp-react'
import { useClearForm } from '../../hooks/use-clear-form'

function Header({ firstname = '' }) {
  const { clearForm } = useClearForm()
  return (
    <>
      <div className={styles.header}>
        <div className={styles.headerContainer}>
          <div className={styles.headerWrapper}>
            <Image
              src="https://www.paypalobjects.com/paypal-ui/logos/svg/paypal-mark-monotone-transparent.svg"
              alt="paypal-logo"
              layout="fill"
            />
          </div>
          <Link href="/">
            <h3 className={styles.leftHeader} onClick={() => clearForm()}>
              Migration Hub
            </h3>
          </Link>
        </div>
        <div className={styles.rightHeaderContainer}>
          <a
            href="https://engineering.paypalcorp.com/confluence/display/SOC/Merchant+Migration+Readiness+Hub"
            target="_blank"
            rel="noreferrer"
          >
            <InformationIcon size="sm" className={styles.headerIcon}>
              <span className={styles.tooltip}>About</span>
            </InformationIcon>
          </a>

          <a
            href="https://engineering.paypalcorp.com/confluence/display/SOC/Migration+Readiness+Hub+-+User+Guide"
            target="_blank"
            rel="noreferrer"
          >
            <GetDirectionsIcon size="sm" className={styles.headerIcon}>
              <span className={styles.tooltip}>Docs</span>
            </GetDirectionsIcon>
          </a>

          <a
            href="https://paypal.slack.com/archives/C03NCQJQ7GT"
            target="_blank"
            rel="noreferrer"
          >
            <ContactUsIcon size="sm" className={styles.headerIcon}>
              <span className={styles.tooltip}>Help</span>
            </ContactUsIcon>
          </a>

          <h4 className={styles.rightHeader}>{firstname}</h4>
        </div>
      </div>
    </>
  )
}

export default Header
