import {
  BodyText,
  Badge,
  Row,
  Col,
  Tooltip,
  Button,
} from '@paypalcorp/pp-react'
import { useState } from 'react'
import DetailsTable from './details-table'
import styles from './evaluation-card.module.scss'

const getStatus = (status) => {
  let resolvedStatus = ''
  switch (status) {
    case 'WARNING':
      resolvedStatus = 'warning'
      break
    case 'SUCCESS':
      resolvedStatus = 'success'
      break
    case 'ERROR':
    default:
      resolvedStatus = 'critical'
      break
  }
  return resolvedStatus
}

const EvaluationCard = ({
  name,
  displayName,
  status,
  summary,
  description,
  data,
}) => {
  const [showDetails, setShowDetails] = useState(false)

  const bgColor = showDetails ? styles.evaluationCardBg : ''
  return (
    <Row className={`${styles.evaluationCardWrapper} ${bgColor}`}>
      <Col lg={3} className={styles.evaluationCard}>
        <BodyText>{displayName}</BodyText>
        <Tooltip name={displayName} description={description} />
      </Col>
      <Col lg={2} className={styles.evaluationCard}>
        <Badge type={getStatus(status)}>{status}</Badge>
      </Col>
      <Col className={styles.evaluationCard} lg={7}>
        <BodyText>
          {summary}
          {data ? (
            <Button
              onClick={() => setShowDetails(!showDetails)}
              tertiary
              className={styles.showHideBtn}
            >
              {showDetails ? 'Hide details' : 'Show details'}
            </Button>
          ) : (
            ''
          )}
        </BodyText>
      </Col>
      {data && showDetails ? <DetailsTable name={name} data={data} /> : ''}
    </Row>
  )
}

export default EvaluationCard
