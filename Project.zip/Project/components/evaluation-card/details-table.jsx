import styles from './details-table.module.scss'
import {
  Table,
  TableCell,
  TableRow,
  TableHead,
  TableHeadingCell,
  TableBody,
} from '@paypalcorp/pp-react'

const headings = {
  //Key is evaluation name
  ACCOUNT_PRICING: ['Product Name', 'Product Category', 'Price'],
  PARTNER_PERMISSIONS: ['Partner Email', 'Permissions Granted'],
}

const DetailsTable = ({ name = '', data }) => {
  return (
    <>
      <Table isFullWidth className={styles.detailsTable}>
        <TableHead>
          <TableRow>
            {headings[name] &&
              headings[name].map((heading, index) => (
                <TableHeadingCell key={index} className={styles.tableHeading}>
                  {heading}
                </TableHeadingCell>
              ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((entry, index) => {
            const cellValues = []
            if (name === 'ACCOUNT_PRICING') {
              cellValues.push(entry.name, entry.category)
              let price = ''
              if (entry.recurring_fee && entry.recurring_fee.value) {
                price = parseInt(entry.recurring_fee.value, 10) / 100
                price += ' ' + entry.recurring_fee.currency_code
                price += ' ' + entry.billing_frequency
              }
              cellValues.push(price)
            } else if (name === 'PARTNER_PERMISSIONS') {
              cellValues.push(entry.actor_email, entry.resources?.join(','))
            }

            return (
              <TableRow key={index}>
                {cellValues.map((value, index) => (
                  <TableCell key={index}>{value}</TableCell>
                ))}
              </TableRow>
            )
          })}
        </TableBody>
      </Table>
    </>
  )
}

export default DetailsTable
