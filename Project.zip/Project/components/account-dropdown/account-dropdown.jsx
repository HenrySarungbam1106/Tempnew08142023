import { useFormData } from '../../context/form-context'
import { Col, DropdownMenu } from '@paypalcorp/pp-react'
import { useEffect } from 'react'
import { API_NAMES, resolveAPIName } from '../commonutils'

const MIGRATION_MAP = new Map([
  [API_NAMES.pro3, [API_NAMES.ordersV2ACDC]],
  [API_NAMES.classicEC, [API_NAMES.ordersV2, API_NAMES.ordersV2ACDC]],
  [API_NAMES.wps, [API_NAMES.ordersV2, API_NAMES.ordersV2ACDC]],
])

function AccountDropdown() {
  const { formData, updateFormData } = useFormData()
  console.log('formData is ', formData)

  useEffect(() => {
    if (!formData.from) {
      const from = API_NAMES.pro3
      updateFormData({
        from,
        to: MIGRATION_MAP.get(from)[0],
      })
    }
  }, [])

  const handleChangeFrom = (event) => {
    const from = resolveAPIName(event.target.value)
    updateFormData({
      from,
      to: MIGRATION_MAP.get(from)[0],
    })
  }

  const handleChangeTo = (event) => {
    updateFormData({
      to: resolveAPIName(event.target.value),
    })
  }

  return (
    <>
      {console.log('render form data is ', formData)}
      <Col form="half">
        <DropdownMenu
          label="Migrate From"
          options={Array.from(MIGRATION_MAP.keys())}
          value={formData.from.value}
          onChange={handleChangeFrom}
          selectedItemIndex={0}
        />
      </Col>
      <Col form="half">
        <DropdownMenu
          label="Migrate To"
          options={MIGRATION_MAP.get(formData.from)}
          value={formData.to.value}
          onChange={handleChangeTo}
          selectedItemIndex={0}
        />
      </Col>
    </>
  )
}

export default AccountDropdown
