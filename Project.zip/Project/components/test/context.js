import { FormContextProvider } from '../../context/form-context'
import { ServerContextProvider } from '../../context/server-context'

export default function context({ children }) {
  return (
    <ServerContextProvider
      value={{
        requestURI: '/merchantintegrationenablement',
        sessionTimeoutConfig: {
          timeout: 7000,
          reminderTimeout: 3000,
          throttle: 1000,
        },
      }}
    >
      <FormContextProvider>{children}</FormContextProvider>
    </ServerContextProvider>
  )
}
