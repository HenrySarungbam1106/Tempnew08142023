import { IncomingMessage, ServerResponse } from 'http'
import { WorldReady } from '@paypalcorp/worldready'

// Assumption: It's client-side, using WorldReady JS.
WorldReady.load(require('../../node_modules/.cache/worldready-metadata.json'))

function constructServerData() {
  return {
    requestURI: '/sampleapp',
    locality: {
      country: 'US',
      timezone: 'America/Los_Angeles',
      locale: 'en-US',
      language: 'en',
      directionality: 'ltr',
    },
    // Empty data here, because this is already loaded (into WorldReady) by
    // paypal-script global-test-setup.
    worldReady: {},
  }
}

function createRequest() {
  const req = new IncomingMessage()
  const res = new ServerResponse(req)
  req.body = {}
  req.headers = {}
  req.get = req.header = (name) => req.headers[name]

  req.query = {
    'country.x': 'US',
    'locale.x': 'en-US',
  }

  req.path = '/sampleapp'
  res.locals = {}
  res.locals.context = {}

  req.tracking = (() => {
    return {
      addData() {},
      doAnalytics() {
        res.locals.context.tracking = {
          fpti: {
            name: 'pta',
            jsURL: 'https://www.paypalobjects.com/staging',
            jsFullUrl: undefined,
            serverURL: 'https://www.paypal.com/webapps/tracking/ts',
            dataString:
              'pgrp=main%3AgenericError%3A404&page=main%3AgenericError%3A404&pgst=1633727646293&calc=d2dcd568ff998&nsid=TuvWjdlmWyZlE96UwV-bUIBLjPcz0Brj&rsta=en_US&pgtf=Nodejs&s=ci&ccpg=US&csci=443b96de77b64d7ebee99afedfc5ae88&comp=errorsnodeweb&tsrce=errorsnodeweb&cu=0&ef_policy=ccpa&erpg=GenericErrorPage',
          },
        }
      },
    }
  })()

  req.res = res
  return req
}

export { createRequest, constructServerData }
