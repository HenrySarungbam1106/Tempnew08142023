import { Button } from '@paypalcorp/pp-react'
import styles from './filter-button.module.scss'

const FilterButton = ({
  name,
  displayName,
  icon,
  count = 0,
  secondary,
  onClick,
}) => {
  console.log('filter button called with ', name, count, secondary)
  return count ? (
    <Button
      size="sm"
      className={styles.displayNameBtn}
      iconComponent={icon}
      onClick={() => onClick(name)}
      secondary={secondary}
    >
      {displayName} ({count})
    </Button>
  ) : (
    <></>
  )
}

// const FilterButton = () => <></>

export default FilterButton
