import styles from './drag-drop.module.scss'
import {
  UploadIcon,
  BodyText,
  Row,
  Col,
  CaptionText,
  LoadingSpinner,
} from '@paypalcorp/pp-react'
import { useRef, useEffect, useState } from 'react'
import {
  isInputAccountNumber,
  isInputPayerId,
  readFileContents,
} from '../commonutils'
import { useFormData } from '../../context/form-context'

function DragDrop() {
  const dragDropRef = useRef(null)
  const fileInputRef = useRef(null)
  const counter = useRef(0)
  const [dragging, setDragging] = useState(false)
  const { formData, updateFormData } = useFormData()

  const draggingStyle = dragging ? styles.uploadStyle : {}

  useEffect(() => {
    /**
     * warning  The ref value 'dragDropRef.current' will likely have changed by the time this effect cleanup function runs. If this ref points
     * to a node rendered by React, copy 'dragDropRef.current' to a variable inside the effect, and use that variable in the cleanup function
     */
    const currentDragRef = dragDropRef.current

    const events = [
      ['dragover', handleDragOver],
      ['drop', handleDrop],
      ['dragenter', handleDragEnter],
      ['dragleave', handleDragLeave],
    ]

    events.forEach((element) => {
      currentDragRef.addEventListener(element[0], element[1])
    })

    return () => {
      events.forEach((element) => {
        currentDragRef.removeEventListener(element[0], element[1])
      })
    }
  }, [])

  /*
    Click to browse function
  */

  const handleFileUpload = async (e) => {
    console.log('Entered file upload with browse')
    e.preventDefault()
    if (e.target.files?.[0]) {
      await processBatchFile(e.target.files[0])
    }
  }

  /*
    common function to handle file upload
  */

  const processBatchFile = async (fileName) => {
    try {
      if (fileName) {
        updateFormData({
          batchReadState: true,
        })

        const accountNumbers = await readFileContents(fileName)
        console.log('account numbers from file are ', accountNumbers)
        //TODO: handle error scenarios

        if (Array.isArray(accountNumbers) && accountNumbers.length > 0) {
          const parsedAccountNumbers = accountNumbers
            .map((number) => ({
              number,
              isPayerId: isInputPayerId(number),
            }))
            .filter(
              ({ number, isPayerId }) =>
                number && (isPayerId || isInputAccountNumber(number)),
            )

          if (parsedAccountNumbers.length === 0) {
            updateFormData({
              batchAccountNumbers: [],
              message: 'Invalid format for Account Number or Payer Id',
              error: true,
              batchReadState: false,
            })
          } else {
            console.log('parsed account numbers is ', parsedAccountNumbers)
            updateFormData({
              batchAccountNumbers: parsedAccountNumbers,
              batchReadState: false,
            })
          }
        }
      }
    } catch (error) {
      updateFormData({
        batchAccountNumbers: [],
        error: true,
        message: `Error processing file. ${error.message}`,
        batchReadState: false,
      })
    }
  }

  /*
    Drag and drop handler functions
  */

  const handleDragOver = (e) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = async (e) => {
    e.preventDefault()
    e.stopPropagation()

    const { files } = e.dataTransfer

    console.log('files is ', files)

    // check if the provided count prop is less than uploaded count of files
    if (files.length > 1) {
      updateFormData({
        message: 'Only 1 file can be uploaded at a time',
        error: true,
      })
      console.log(`Only 1 file can be uploaded at a time`)
      counter.current = 0
      setDragging(false)
      return
    }

    // check if some uploaded file is not in one of the allowed formats
    const fileExt = files[0].name.substring(files[0].name.lastIndexOf('.'))
    if (['.xls', '.txt', '.xlsx', '.csv'].indexOf(fileExt) < 0) {
      updateFormData({
        message: 'Only xls,txt,xlsx,csv file formats are acceptable',
        error: true,
      })
      console.log(`Only xls,txt,xlsx,csv file formats are acceptable`)
      counter.current = 0
      setDragging(false)
      return
    }

    if (files && files.length > 0) {
      console.log('calling process batch file')
      console.log('file is ', files[0])

      await processBatchFile(files[0])
    } else {
      console.log('nothing to process')
    }

    counter.current = 0
    setDragging(false)
  }

  const handleDragEnter = (e) => {
    console.log('drag enter event is ', e)
    e.preventDefault()
    e.stopPropagation()

    counter.current++
    setDragging(true)
  }

  const handleDragLeave = (e) => {
    e.preventDefault()
    e.stopPropagation()

    counter.current--

    if (counter.current === 0) {
      setDragging(false)
    }
  }

  /*
    End drag and drop handler functions
  */

  return (
    <Row>
      <Col form="full" align="center">
        <input
          ref={fileInputRef}
          onChange={handleFileUpload}
          type="file"
          className={styles.input}
          data-testid="file-upload"
          accept=".csv,.txt,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
        />

        <Row>
          <Col form="full" align="center">
            <CaptionText>
              Upload a CSV file containing account numbers or payer IDs
            </CaptionText>
          </Col>
        </Row>

        <div
          ref={dragDropRef}
          data-testid="drag-drop"
          onClick={() => fileInputRef.current.click()}
          className={`${styles.upload} ${draggingStyle} `}
          style={
            dragging
              ? {
                  border: '3px dashed black',
                }
              : {}
          }
        >
          {formData.batchReadState ? (
            <div>
              <LoadingSpinner screenReaderText="loading" size="lg" />
              <BodyText>Processing...</BodyText>
            </div>
          ) : (
            <div className={styles.insideDiv}>
              <UploadIcon size="lg" className={styles.UploadIcon} />
              <BodyText>Drag and drop or click to browse</BodyText>
            </div>
          )}
        </div>
        <Row>
          <Col form="full" align="center">
            <CaptionText>
              txt xls csv extension | Up to 5000 account numbers
            </CaptionText>
          </Col>
        </Row>
      </Col>
    </Row>
  )
}

export default DragDrop
