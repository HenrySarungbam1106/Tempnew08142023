import { BodyText, ArrowLeftIcon, Link } from '@paypalcorp/pp-react'
import NextLink from 'next/link'
import { useServerData } from '../../context/server-context'
import { appendSkipSSO } from '../commonutils'
import { useClearForm } from '../../hooks/use-clear-form'
import styles from './breadcrumb.module.scss'
const BreadCrumb = () => {
  const { serverData } = useServerData()
  const { clearForm } = useClearForm()

  let backHref = '/'

  if (serverData.skipSSO) {
    backHref = appendSkipSSO(backHref)
  }

  return (
    <>
      <NextLink href={backHref}>
        <Link
          leftIcon={<ArrowLeftIcon size="sm" />}
          className={styles.arrowLeftIcon}
          onClick={() => clearForm()}
        >
          {' '}
          Home{' '}
        </Link>
      </NextLink>
      <BodyText className={styles.bodyTextContainer}>
        /<span className={styles.bodyTextSpn}>Migration Details</span>
      </BodyText>
    </>
  )
}

export default BreadCrumb
