import * as XLSX from 'xlsx'

const isXLSFile = (file) =>
  file.name.endsWith('xls') || file.name.endsWith('xlsx')

export const readExcelContents = (binaryData) => {
  let workbook = XLSX.read(binaryData, {
    type: 'binary',
  })
  if (workbook.Sheets) {
    const firstSheet = Object.keys(workbook.Sheets)[0]
    const csv = XLSX.utils
      .sheet_to_csv(workbook.Sheets[firstSheet])
      .replace(/"/g, '')
    return csv.replace(/"/g, '')
  }
  return ''
}

export const readFileContents = (file) => {
  const reader = new FileReader()
  return new Promise((resolve, reject) => {
    reader.onload = () => {
      let text = reader.result
      if (isXLSFile) {
        text = readExcelContents(text)
      }
      const accountNumbrs = text.split(/[,\n\r\s]+/g)
      resolve(accountNumbrs)
    }
    if (isXLSFile(file)) {
      reader.readAsBinaryString(file)
    } else {
      reader.readAsText(file)
    }
    reader.onerror = () => {
      reject(`Error reading file ${file}`)
    }
  })
}

export const isInputAccountNumber = (input) => /^([\w]+)$/.test(input)

export const isInputPayerId = (input) => /^(?=.*[A-Z])[A-Z0-9]{13}$/.test(input)

export const appendSkipSSO = (url) => {
  let separator = '?'
  if (~url.indexOf(separator)) {
    separator = '&'
  }
  return url.concat(`${separator}pp-ft-skipsso=true`)
}

export const API_NAMES = {
  pro3: {
    primaryText: 'Website Payments Pro (3.0)',
    value: 'PRO_3_0',
  },
  classicEC: {
    primaryText: 'Express Checkout - NVP/SOAP',
    value: 'CLASSIC_EC',
  },
  ordersV2: {
    primaryText: 'Orders v2 with Standard Cards',
    value: 'ORDERS_V2',
  },
  ordersV2ACDC: {
    primaryText: 'Orders v2 with Advanced Cards',
    value: 'ORDERS_V2_ACDC',
  },
  wps: {
    primaryText: 'Website Payments Standard',
    value: 'WPS',
  },
}

export const resolveAPIName = (apiValue) =>
  apiValue
    ? Object.values(API_NAMES).find(({ value }) => value === apiValue)
    : null
