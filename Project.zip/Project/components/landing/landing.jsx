import styles from './landing.module.scss'
import {
  Container,
  Row,
  Col,
  SegmentedController,
  SegmentedControllerPanel,
  HeadingText,
} from '@paypalcorp/pp-react'
import InputForm from '../input-form/input-form'
import InfoLink from '../info-link/info-link'
import BatchUpload from '../batch-upload/batch-upload'
import { useFormData } from '../../context/form-context'
import { useClearForm } from '../../hooks/use-clear-form'

export default function Landing(props) {
  console.log('serverdata is ', props.serverData)
  const { formData, updateFormData } = useFormData()
  const { clearForm } = useClearForm()

  return (
    <>
      <Container className={styles.container}>
        <Row>
          <Col>
            {/* <HeadingText size="sm" className={styles.heading}> */}
            <HeadingText size="sm" className={styles.heading}>
              Migration Readiness Search
            </HeadingText>
          </Col>
        </Row>
        <Row>
          <Col>
            <SegmentedController
              name="TabsGroup1"
              tabsWrapperClassName={styles.tabs}
              selectedTabIdx={formData.batchMode ? 1 : 0}
              tabs={[
                {
                  label: 'Individual account',
                  id: 'group1-tab1',
                  panelId: 'group1-panel1',
                },
                {
                  label: 'Batch upload',
                  id: 'group1-tab2',
                  panelId: 'group1-panel2',
                },
              ]}
              onClick={(e) => {
                clearForm()
                const { id } = e.target
                if (id === 'group1-tab1' && formData.batchMode) {
                  updateFormData({ batchMode: false })
                } else if (id === 'group1-tab2' && !formData.batchMode) {
                  updateFormData({ batchMode: true })
                }
              }}
            >
              <SegmentedControllerPanel
                id="group1-tab1"
                panelId="group1-panel1"
              >
                <InputForm />
              </SegmentedControllerPanel>
              <SegmentedControllerPanel
                id="group1-tab2"
                panelId="group1-panel2"
              >
                <BatchUpload />
              </SegmentedControllerPanel>
            </SegmentedController>
          </Col>
        </Row>

        {!formData.batchMode && (
          <Row className={styles.infoContainer}>
            <Col
              align="left"
              xs={12}
              sm={4}
              md={4}
              lg={4}
              className={styles.infoColumns}
            >
              <InfoLink
                text=" Learn more about the Migration Readiness Hub and what inspired its
        creation."
                heading="About Migration Hub"
                link1Text="Know More"
                link1Target="https://engineering.paypalcorp.com/confluence/display/SOC/Merchant+Migration+Readiness+Hub"
              />
            </Col>

            <Col
              align="left"
              xs={12}
              sm={4}
              md={4}
              lg={4}
              className={styles.infoColumns}
            >
              <InfoLink
                text="Learn how to prepare your merchants for moving to the latest
              PayPal integrations."
                heading="Getting started"
                link1Text="Launch"
                link1Target="https://engineering.paypalcorp.com/confluence/display/SOC/Migration+Readiness+Hub+-+User+Guide"
              />
            </Col>
            <Col
              align="left"
              xs={12}
              sm={4}
              md={4}
              lg={4}
              className={styles.infoColumns}
            >
              <InfoLink
                text="Reach out to us for any questions via slack or email using the
              links below."
                heading="Contact us"
                link1Text="Email"
                link1Target="mailto:soc-migrationhub@paypal.com"
                link2Text="Slack"
                link2Target="https://paypal.slack.com/archives/C03NCQJQ7GT"
              />
            </Col>
          </Row>
        )}
      </Container>
    </>
  )
}
