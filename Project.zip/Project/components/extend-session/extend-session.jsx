import {
  HeadingText,
  BodyText,
  Button,
  Sheet,
  Container,
} from '@paypalcorp/pp-react'
import { useServerData } from '../../context/server-context'
import { useState, useRef, useEffect } from 'react'
import { useIdleTimer } from 'react-idle-timer'
import pRetry from 'p-retry'
import { appendSkipSSO } from '../commonutils'
import styles from './extend-session.module.scss'

const ExtendSession = () => {
  useEffect(() => {
    console.log('session: Timeout configuration', {
      timeout,
      reminderTimeout,
      throttle,
    })
  }, [])

  const { serverData } = useServerData()
  const { timeout, reminderTimeout, throttle } =
    serverData.sessionTimeoutConfig ?? {}
  const lastServerRefresh = useRef(Date.now())

  const callAuthEndpoint = async () => {
    let extendURL = `${serverData.requestURI}/api/v1/extend-session`

    if (serverData.skipSSO) {
      extendURL = appendSkipSSO(extendURL)
    }

    const res = await fetch(extendURL, { method: 'HEAD', redirect: 'error' })
    if (!res.ok) {
      throw new Error(res.statusText)
    } else {
      return res.status
    }
  }

  const logUserOut = () => {
    console.log('session: Logging out user')
    let logoutURL = `${serverData.requestURI}/api/v1/logout`

    if (serverData.skipSSO) {
      logoutURL = appendSkipSSO(logoutURL)
    }

    window.location = logoutURL
  }

  const onExtendSession = async () => {
    try {
      await pRetry(callAuthEndpoint, { retries: 3 })
      activate()
      lastServerRefresh.current = Date.now()
      if (open) {
        setOpen(false)
      }
      console.log('session: Extended session')
    } catch (err) {
      console.log(
        'session: Unable to extend session, logging user out ',
        err.message,
      )
      logUserOut()
    }
  }

  const [open, setOpen] = useState(false)

  const onPrompt = () => {
    setOpen(true)
  }

  const onAction = () => {
    if (!open && Date.now() - lastServerRefresh.current > timeout) {
      onExtendSession()
    }
  }

  const { activate } = useIdleTimer({
    timeout, //idle timeout
    onIdle: logUserOut, //what to do when user is completely idle (log em out)
    onPrompt, //what to do on prompt
    promptBeforeIdle: reminderTimeout, //when to prompt
    onAction,
    throttle, //onaction event throttle
  })

  return (
    <Sheet isOpen={open} noCloseButton={true}>
      <Container className={styles.extendContainer}>
        <img
          height="80px"
          width="80px"
          src="https://www.paypalobjects.com/paypal-ui/illustrations/focused/svg/out-of-time-hourglass.svg"
          alt="empty-warning"
        />
        <HeadingText size="sm" className={styles.extendHeadingText}>
          Need more time?
        </HeadingText>
        <BodyText className={styles.extendBodyText}>
          We&apos;ll log you out in a few moments due to inactivity.
        </BodyText>

        <Button
          id="extendSession-btn"
          name="extendSession"
          onClick={onExtendSession}
        >
          Stay Logged In
        </Button>

        <Button
          id="extendSession-btn-logout"
          name="extendSessionLogout"
          onClick={logUserOut}
          className={styles.extendLogoutBtn}
          tertiary
        >
          Log out
        </Button>
      </Container>
    </Sheet>
  )
}

export default ExtendSession
