import { Alert } from '@paypalcorp/pp-react'
import { useFormData } from '../../context/form-context'
import styles from './notify.module.scss'
const Notify = () => {
  const { formData, updateFormData } = useFormData()

  return formData.message ? (
    <Alert
      className={styles.notifyContainer}
      type={formData.error ? 'error' : 'success'}
      aria-label="batch response alert"
      closeButton={{
        'aria-label': 'dismiss alert',
        onClick: () => {
          updateFormData({
            message: '',
            error: false,
          })
        },
      }}
    >
      {formData.message}
    </Alert>
  ) : (
    ''
  )
}

export default Notify
