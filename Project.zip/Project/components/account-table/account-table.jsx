import {
  Table,
  DeleteIcon,
  Row,
  Col,
  BodyText,
  Button,
} from '@paypalcorp/pp-react'
import { useFormData } from '../../context/form-context'

import styles from './account-table.module.scss'
const WhiteSpace = () => <span>&nbsp;&nbsp;&nbsp;</span>
//const WhiteSpace = () => <></>
const AccountTable = () => {
  const { formData, updateFormData } = useFormData()
  return (
    <>
      {/* <Row>
        <Col style={{
          display: 'flex',
        }}>
        <BodyText>
          Total accounts: {formData.batchAccountNumbers.length}
        </BodyText>
     
      <Button tertiary iconComponent={DeleteIcon} style={{
        padding: '0px'
      }}> Delete</Button>
      </Col>
      </Row> */}
      <Table className={styles.accountTableContainer} scroll tabIndex={0}>
        <thead>
          <tr>
            <th>
              <WhiteSpace />
              No.
            </th>
            <th>Account Info</th>
            <th>Type</th>
          </tr>
        </thead>
        <tbody>
          {formData.batchAccountNumbers.map(({ number, isPayerId }, index) => (
            <tr key={index}>
              <td>
                <WhiteSpace />
                {index + 1}
              </td>
              <td>{number}</td>
              <td>
                {isPayerId ? 'Payer ID' : 'Account Number'}
                <WhiteSpace />
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
      {/* <AddIcon
        size="sm"
        style={{
          transform: 'rotate(45deg)',
          marginLeft: '0.5rem',
          verticalAlign: 'top',
          cursor: 'pointer',
        }}
        onClick={() => updateFormData({ batchAccountNumbers: [] })}
      /> */}
      <Row>
        <Col className={styles.accountTableCol}>
          <BodyText>
            Total accounts: <span>{formData.batchAccountNumbers.length}</span>
          </BodyText>

          <Button
            tertiary
            iconComponent={DeleteIcon}
            className={styles.accountTableClearBtn}
            onClick={() => updateFormData({ batchAccountNumbers: [] })}
          >
            Clear
          </Button>
        </Col>
      </Row>
    </>
  )
}

export default AccountTable
