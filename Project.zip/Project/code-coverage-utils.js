//File doesn't go through transpilation

const environment = require('environment-paypal')

module.exports.shouldInstrumentCode =
  environment.isNotProd() &&
  environment.isNotSandbox() &&
  'INSTRUMENT_CODE' in process.env
