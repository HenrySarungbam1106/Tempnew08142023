# merchmigrationnodeweb

This is a [Next.js](https://nextjs.org/) sample app

## Getting Started

First, run the development server:

```bash
npm run dev
```

Open [http://localhost.paypal.com:8000/sampleapp](http://localhost.paypal.com:8000/sampleapp) with your browser to see the result.

You can start editing the page by modifying `pages/[[...default]].js`. The page auto-updates as you edit the file.

## HMR and nginx

If you're accessing the app locally through nginx, add this block to your nginx config to enable Hot Module Replacement (HMR):

```
location ~* /webpack-hmr {
    proxy_pass http://127.0.0.1:8000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
}
```

## Resources

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.
- [Next.js - Migrating from dustjs](https://engineering.paypalcorp.com/confluence/display/WebEng/Next.js+-+Migrating+from+dustjs)
