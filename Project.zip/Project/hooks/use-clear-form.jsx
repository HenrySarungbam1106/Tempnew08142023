import { useFormData } from '../context/form-context'

export const useClearForm = () => {
  const { updateFormData } = useFormData()

  const clearForm = () => {
    updateFormData({
      error: false,
      message: '',
      accountNumber: '',
      isAccount: false,
      inputErrorText: '',
      batchAccountNumbers: [],
      batchButtonState: 'initial',
    })
  }

  return {
    clearForm,
  }
}
