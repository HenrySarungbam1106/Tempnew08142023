/// <reference types="cypress" />
context('Nav', () => {
  beforeEach(() => {
    cy.visit('?pp-ft-skipsso=true')
  })

  it('should have root element', () => {
    cy.get('#root').should(($div) => {
      expect($div).to.have.length(1)
    })
  })

  it('should load home page', () => {
    cy.contains('Migration Readiness Search')
    cy.contains('Batch upload').click()
    cy.contains('Drag and drop or click to browse').should('be.visible')
  })

  // it('should navigate to help page', () => {
  //   cy.get('nav').should(($nav) => {
  //     expect($nav).to.have.length(2)
  //     expect($nav.find('a:contains("help")')).to.have.length(1)
  //   })
  //   cy.get('nav').find('a:contains("help")').click()
  //   cy.get('h1').contains('Help')
  // })
})
