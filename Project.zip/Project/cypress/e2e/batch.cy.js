import path from 'path'
import { batchUploadData } from '../fixtures/batch/batch.data.js'

describe('batch upload', () => {
  beforeEach(() => {
    cy.visit('?pp-ft-skipsso=true')
    cy.findByRole('tab', { name: /Batch upload/ }).click()
    cy.contains('Drag and drop or click to browse').should('be.visible')
  })

  batchUploadData.usecases.forEach((usecase) =>
    it(usecase.description, () => {
      const filesToUpload = usecase.files.map((fileName) =>
        path.join(__dirname, '../fixtures/batch', fileName),
      )

      cy.uploadFile(filesToUpload, usecase.shouldDragDrop)

      if (usecase.totalAccountNumbers && usecase.from && usecase.to) {
        cy.verifyBatchInputTable(usecase.totalAccountNumbers, true, true)
        cy.fillMigrationDetails(null, usecase.from, usecase.to)
        cy.findByRole('button', { name: /submit/i }).click()
      }

      cy.findByRole('alert', { name: /batch response alert/i }).within(() => {
        cy.findByText(usecase.response).should('be.visible')
        cy.findByRole('button', { name: /dismiss alert/i }).click()
      })

      cy.findByRole('button', { name: /dismiss alert/i }).should('not.exist')
    }),
  )
})
