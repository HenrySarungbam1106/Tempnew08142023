import { pro3data } from '../fixtures/pro3.data'

describe('pro3.0 to orders v2', () => {
  beforeEach(() => {
    cy.visit('?pp-ft-skipsso=true')
  })

  pro3data.accounts.forEach((account) => {
    it(account.description, () => {
      cy.findByText('Migration Readiness Search')
      cy.fillMigrationDetails(account.accountNumber, account.from, account.to)
      cy.findByRole('button', { name: /Submit/ }).click()
      cy.findByText('Migration Readiness Details')

      //Verify account details section
      cy.findByText('Account details')
      account.accountDetails.forEach(({ name, value }) => {
        cy.verifyAccountField(name, value)
      })

      //Readiness check assertions
      cy.findByText(/Evaluations/)
      account.evaluations.forEach(({ name, status, description }) => {
        cy.verifyEvaluation(name, status, description)
      })
    })
  })
})
