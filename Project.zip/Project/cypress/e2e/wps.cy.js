import { wpsData } from '../fixtures/wps.data'

describe('wps to orders v2 advanced', () => {
  beforeEach(() => {
    cy.visit('?pp-ft-skipsso=true')
  })

  wpsData.accounts.forEach((account) => {
    it(account.description, () => {
      cy.findByText('Migration Readiness Search')
      cy.fillMigrationDetails(account.accountNumber, account.from, account.to)
      cy.findByRole('button', { name: /Submit/ }).click()
      cy.findByText('Migration Readiness Details')

      //Verify account details section
      cy.findByText('Account details')
      account.accountDetails.forEach(({ name, value }) => {
        cy.verifyAccountField(name, value)
      })
      //cy.get('.merchantmigration-cpdngk-links_base-text_body_strong').click()
      //Readiness check assertions
      cy.findByText(/Evaluations/)
      account.evaluations.forEach(({ name, status, description }) => {
        cy.verifyEvaluation(name, status, description)
      })
      cy.get('a:contains("links")').click()
    })
  })

})

// it('should navigate to help page', () => {
//     // cy.get('nav').should(($nav) => {
//     //   expect($nav).to.have.length(2)
//     //   expect($nav.find('a:contains("help")')).to.have.length(1)
//     // })
//     cy.find('a:contains("link")').click()
//    // cy.get('h1').contains('Help')
//   })