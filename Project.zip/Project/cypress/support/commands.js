// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add("login", (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add("drag", { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add("dismiss", { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite("visit", (originalFn, url, options) => { ... })

import '@testing-library/cypress/add-commands'

Cypress.Commands.add(
  'verifyEvaluation',
  (evaluationName, status, description) => {
    const descRegex = new RegExp(`${description}*`, 'gi')

    cy.findByTestId(evaluationName).within(() => {
      cy.findAllByText(evaluationName).should('have.length', 2)
      cy.findByText(status).should('be.visible')
      cy.findByText(descRegex).should('be.visible')
      cy.findByRole('button', { name: evaluationName }).should('be.visible')
    })
  },
)

Cypress.Commands.add('verifyAccountField', (name, value) => {
  //Ideally we should be able to use findByDisplayText for Account details,
  //but due to way pp-react renders the component, we have to use this workaround
  const attrRegex = new RegExp(`${name}`, 'gi')
  cy.findByDisplayValue(value, { timeout: 15000 })
    .should('have.attr', 'name')
    .and('match', attrRegex)
})

Cypress.Commands.add('fillMigrationDetails', (accountNo, from, to) => {
  if (accountNo) {
    cy.findByLabelText('Account Number or Payer ID').type(accountNo)
  }

  cy.findByLabelText('Migrate From').click()
  cy.findByRole('option', { name: from }).click()

  cy.findByLabelText('Migrate To').click()
  cy.findByRole('option', { name: to }).click()
})

Cypress.Commands.add('uploadFile', (fileArray, shouldDragDrop) => {
  if (!shouldDragDrop) {
    cy.get('input[type=file]').selectFile(fileArray, {
      force: true,
      action: 'select',
    })
  } else {
    cy.findByText(/drag and drop/i).selectFile(fileArray, {
      action: 'drag-drop',
    })
  }
})

Cypress.Commands.add(
  'verifyBatchInputTable',
  (totalAccountNumbers, payerIDPresent, accountNumberPresent) => {
    cy.findByRole('table').within(() => {
      cy.findByRole('columnheader', {
        name: /account info/i,
      }).scrollIntoView()

      cy.findByRole('columnheader', {
        name: /type/i,
      }).should('be.visible')

      if (payerIDPresent) {
        cy.findAllByRole('cell', { name: /payer id/i }).should(
          'have.length.greaterThan',
          1,
        )
      }

      if (accountNumberPresent) {
        cy.findAllByRole('cell', { name: /account number/i }).should(
          'have.length.greaterThan',
          1,
        )
      }
    })

    cy.findByText(/total accounts/i).within(() => {
      cy.findByText(totalAccountNumbers).should('be.visible')
    })

    cy.findByRole('button', { name: /clear/i }).should('be.visible')
  },
)
