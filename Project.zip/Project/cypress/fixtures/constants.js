export const accountNameRegex = {
  pro3: /website payments pro \(3\.0\)/i,
  ordersV2: /orders v2 with advanced cards/i,
  wps: /website payments standard/i,
}

export const accountDetailFeilds = {
  accounName: 'Account Name',
  countryCode: 'Country Code',
  primaryCurrency: 'Primary Currency',
  virtualTerminal: 'Virtual Terminal',
  referenceTransactions: 'Reference Transactions',
  holdingCurrency: 'Holding Currency',
}

export const batchResponseRegex = {
  success: /batch id.*[\w]+.*/i,
  errorTooManyFiles: /only 1 file/i,
  errorInvalidFile: /file formats are acceptable/i,
}
