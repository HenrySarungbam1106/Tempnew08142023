import { accountNameRegex, batchResponseRegex } from '../constants'
export const batchUploadData = {
  usecases: [
    {
      description: 'Excel input file - file upload',
      shouldDragDrop: false,
      files: ['test-account-excel.xlsx'], //should exist in fixtures/batch folder
      totalAccountNumbers: 772,
      from: accountNameRegex.pro3,
      to: accountNameRegex.ordersV2,
      response: batchResponseRegex.success,
    },
    {
      description: 'Excel input file - drag and drop',
      shouldDragDrop: true,
      files: ['test-account-excel.xlsx'], //should exist in fixtures/batch folder
      totalAccountNumbers: 772,
      from: accountNameRegex.pro3,
      to: accountNameRegex.ordersV2,
      response: batchResponseRegex.success,
    },
    {
      description: 'Invalid file format',
      shouldDragDrop: true,
      files: ['invalid-extension.data'], //should exist in fixtures/batch folder
      totalAccountNumbers: '',
      from: '',
      to: '',
      response: batchResponseRegex.errorInvalidFile,
    },
    {
      description: 'Multiple files',
      shouldDragDrop: true,
      files: ['test-account-excel.xlsx', 'test-account.txt'], //should exist in fixtures/batch folder
      totalAccountNumbers: '',
      from: '',
      to: '',
      response: batchResponseRegex.errorTooManyFiles,
    },
  ],
}
