import { accountNameRegex, accountDetailFeilds } from './constants'
export const wpsData = {
  accounts: [
    {
      description: 'US business account',
      accountNumber: '88SPDGKYK28LG', //payerID
      from: accountNameRegex.wps,
      to: accountNameRegex.ordersV2,
      accountDetails: [
        {
          name: accountDetailFeilds.accounName,
          value: 'MEPE Automation',
        },
        {
          name: accountDetailFeilds.countryCode,
          value: 'CA',
        },
        {
          name: accountDetailFeilds.primaryCurrency,
          value: 'CAD',
        },
        {
          name: accountDetailFeilds.holdingCurrency,
          value: 'USD',
        },
        {
          name: accountDetailFeilds.referenceTransactions,
          value: 'NOT_ACTIVE',
        },
      ],
      evaluations: [
        {
          name: 'Pricing',
          status: 'SUCCESS',
          description: 'Merchant is on standard pricing, Category code: 10A',
        },
        {
          name: 'PPCP Custom',
          status: 'WARNING',
          description:
            'Merchant has not yet been approved for Advanced Debit and Credit Cards.',
        },
        {
          name: 'Account Status',
          status: 'WARNING',
          description: 'Merchant is not Verified.',
        },
        {
          name: 'Compliance - CIP',
          status: 'WARNING',
          description:
            "Account is based in CA. This country's CIP process, if any, has not been evaluated by this hub.",
        },
        {
          name: 'Beneficial Owner',
          status: 'WARNING',
          description: 'Beneficial Owner has not been provided.',
        },
        {
          name: 'Partner Permissions',
          status: 'SUCCESS',
          description: 'No Third Party permissions are present on the account.',
        },
        {
          name: 'Reporting',
          status: 'SUCCESS',
          description: 'Merchant is not subscribed to any reports.',
        },
        {
          name: 'Account Pricing',
          status: 'WARNING',
          description:
            'Merchant is paying monthly fees. Please contact MOST team',
        },
        {
          name: 'Recurring Billing',
          status: 'SUCCESS',
          description: 'Merchant does not have active billing agreements.',
        },
      ],
    },
  ],
}
