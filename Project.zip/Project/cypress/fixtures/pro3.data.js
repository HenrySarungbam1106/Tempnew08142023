import { accountNameRegex, accountDetailFeilds } from './constants'
export const pro3data = {
  accounts: [
    {
      description: 'US business account',
      accountNumber: '4793185386290906733',
      from: accountNameRegex.pro3,
      to: accountNameRegex.ordersV2,
      accountDetails: [
        {
          name: accountDetailFeilds.accounName,
          value: "Gordons' Custom Upholstery",
        },
        {
          name: accountDetailFeilds.countryCode,
          value: 'US',
        },
        {
          name: accountDetailFeilds.primaryCurrency,
          value: 'USD',
        },
        {
          name: accountDetailFeilds.virtualTerminal,
          value: 'NOT_SUBSCRIBED',
        },
        {
          name: accountDetailFeilds.referenceTransactions,
          value: 'NOT_ACTIVE',
        },
      ],
      evaluations: [
        {
          name: 'Pricing',
          status: 'WARNING',
          description: 'Merchant has custom pricing. Category code: 204HN',
        },
        {
          name: 'PPCP Custom',
          status: 'WARNING',
          description:
            'Merchant has not yet been approved for Advanced Debit and Credit Cards.',
        },
        {
          name: 'Account Status',
          status: 'WARNING',
          description: 'Merchant is not Verified.',
        },
        {
          name: 'Compliance - CIP',
          status: 'WARNING',
          description: 'CIP verification needs more data from the merchant.',
        },
        {
          name: 'Beneficial Owner',
          status: 'SUCCESS',
          description: 'Beneficial owner present on account.',
        },
        {
          name: 'Partner Permissions',
          status: 'SUCCESS',
          description: 'No Third Party permissions are present on the account.',
        },
        {
          name: 'Reporting',
          status: 'SUCCESS',
          description: 'Merchant is not subscribed to any reports.',
        },
        {
          name: 'Account Pricing',
          status: 'SUCCESS',
          description: 'Merchant is not paying any monthly fees.',
        },
        {
          name: 'Recurring Billing',
          status: 'SUCCESS',
          description: 'Merchant does not have active billing agreements.',
        },
      ],
    },
    {
      description: 'Non US business account',
      accountNumber: '5076039551413196242',
      from: accountNameRegex.pro3,
      to: accountNameRegex.ordersV2,
      accountDetails: [
        {
          name: accountDetailFeilds.accounName,
          value: "Doug's Burger Den",
        },
        {
          name: accountDetailFeilds.countryCode,
          value: 'GB',
        },
        {
          name: accountDetailFeilds.primaryCurrency,
          value: 'GBP',
        },
        {
          name: accountDetailFeilds.virtualTerminal,
          value: 'NOT_SUBSCRIBED',
        },
        {
          name: accountDetailFeilds.referenceTransactions,
          value: 'NOT_ACTIVE',
        },
      ],
      evaluations: [
        {
          name: 'Pricing',
          status: 'SUCCESS',
          description: 'Merchant is on standard pricing, Category code: 10A',
        },
        {
          name: 'PPCP Custom',
          status: 'WARNING',
          description:
            'Merchant has not yet been approved for Advanced Debit and Credit Cards.',
        },
        {
          name: 'Account Status',
          status: 'WARNING',
          description: 'Merchant is not Verified.',
        },
        {
          name: 'Compliance - CIP',
          status: 'WARNING',
          description:
            "Account is based in GB. This country's CIP process, if any, has not been evaluated by this hub.",
        },
        {
          name: 'Beneficial Owner',
          status: 'WARNING',
          description: 'Beneficial Owner has not been provided.',
        },
        {
          name: 'Partner Permissions',
          status: 'SUCCESS',
          description: 'No Third Party permissions are present on the account.',
        },
        {
          name: 'Reporting',
          status: 'SUCCESS',
          description: 'Merchant is not subscribed to any reports.',
        },
        {
          name: 'Account Pricing',
          status: 'SUCCESS',
          description: 'Merchant is not paying any monthly fees.',
        },
        {
          name: 'Recurring Billing',
          status: 'SUCCESS',
          description: 'Merchant does not have active billing agreements.',
        },
      ],
    },
    {
      description: 'Personal account',
      accountNumber: '4779771698829071724',
      from: accountNameRegex.pro3,
      to: accountNameRegex.ordersV2,
      accountDetails: [
        {
          name: accountDetailFeilds.countryCode,
          value: 'US',
        },
        {
          name: accountDetailFeilds.primaryCurrency,
          value: 'USD',
        },
        {
          name: accountDetailFeilds.virtualTerminal,
          value: 'NOT_SUBSCRIBED',
        },
        {
          name: accountDetailFeilds.referenceTransactions,
          value: 'NOT_ACTIVE',
        },
      ],
      evaluations: [
        {
          name: 'Pricing',
          status: 'WARNING',
          description: 'Merchant has custom pricing. Category code: 0A.',
        },
        {
          name: 'PPCP Custom',
          status: 'WARNING',
          description:
            'Merchant has not yet been approved for Advanced Debit and Credit Cards.',
        },
        {
          name: 'Account Status',
          status: 'WARNING',
          description:
            'Account is a Personal account. Please have merchant upgrade to a Business account.',
        },
        {
          name: 'Compliance - CIP',
          status: 'WARNING',
          description: 'CIP verification needs more data from the merchant.',
        },
        {
          name: 'Beneficial Owner',
          status: 'WARNING',
          description:
            'Beneficial Owner has not been provided as this is PERSONAL account.',
        },
        {
          name: 'Partner Permissions',
          status: 'SUCCESS',
          description: 'No Third Party permissions are present on the account.',
        },
        {
          name: 'Reporting',
          status: 'SUCCESS',
          description: 'Merchant is not subscribed to any reports.',
        },
        {
          name: 'Account Pricing',
          status: 'SUCCESS',
          description: 'Merchant is not paying any monthly fees.',
        },
        {
          name: 'Recurring Billing',
          status: 'SUCCESS',
          description: 'Merchant does not have active billing agreements.',
        },
      ],
    },
    {
      description: 'Premier account',
      accountNumber: '4779569477681264984',
      from: accountNameRegex.pro3,
      to: accountNameRegex.ordersV2,
      accountDetails: [
        {
          name: accountDetailFeilds.countryCode,
          value: 'US',
        },
        {
          name: accountDetailFeilds.primaryCurrency,
          value: 'USD',
        },
        {
          name: accountDetailFeilds.virtualTerminal,
          value: 'NOT_SUBSCRIBED',
        },
        {
          name: accountDetailFeilds.referenceTransactions,
          value: 'NOT_ACTIVE',
        },
      ],
      evaluations: [
        {
          name: 'Pricing',
          status: 'SUCCESS',
          description: 'Merchant is on standard pricing, Category code: 10A',
        },
        {
          name: 'PPCP Custom',
          status: 'WARNING',
          description:
            'Merchant has not yet been approved for Advanced Debit and Credit Cards.',
        },
        {
          name: 'Account Status',
          status: 'WARNING',
          description:
            'Account is a Premier account. Please have merchant upgrade to a Business account.',
        },
        {
          name: 'Compliance - CIP',
          status: 'WARNING',
          description: 'CIP verification needs more data from the merchant.',
        },
        {
          name: 'Beneficial Owner',
          status: 'WARNING',
          description:
            'Beneficial Owner has not been provided as this is PREMIER account.',
        },
        {
          name: 'Partner Permissions',
          status: 'SUCCESS',
          description: 'No Third Party permissions are present on the account.',
        },
        {
          name: 'Reporting',
          status: 'SUCCESS',
          description: 'Merchant is not subscribed to any reports.',
        },
        {
          name: 'Account Pricing',
          status: 'SUCCESS',
          description: 'Merchant is not paying any monthly fees.',
        },
        {
          name: 'Recurring Billing',
          status: 'SUCCESS',
          description: 'Merchant does not have active billing agreements.',
        },
      ],
    },
    {
      description: 'Closed account',
      accountNumber: '4776006341855581692',
      from: accountNameRegex.pro3,
      to: accountNameRegex.ordersV2,
      accountDetails: [],
      evaluations: [
        {
          name: 'Account Status',
          status: 'WARNING',
          description: 'Account is closed. Account may not be upgraded.',
        },
      ],
    },
  ],
}
