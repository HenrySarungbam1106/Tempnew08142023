/// <reference types="cypress" />
// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

// This function is called when a project is opened or re-opened (e.g. due to
// the project's config changing)
const path = require('path')
const shush = require('shush')
const { shouldInstrumentCode } = require('./../../code-coverage-utils')

function calculateOrigin({ stageName = '', port = 8000 }) {
  const isStageTest = Boolean(stageName)
  const origin = isStageTest
    ? `https://www.${stageName}.qa.paypal.com`
    : `http://localhost.paypal.com:${port}`
  return origin
}
// In various places during Cypress tests we need to know the origin. Cypress
// executes in both a Node.js process (plugins/main.js) as well as inside a
// browser environment (everything else), so this method is useful for checking
// the correct env variables in order to correctly calculate the the origin
function getOrigin() {
  if (typeof Cypress !== 'undefined') {
    return calculateOrigin({
      stageName: Cypress.env('STAGE'),
      port: Cypress.env('PORT'),
    })
  }
  if (process.env.BASE_URL) {
    // Use BASE_URL if available
    /*eslint no-useless-escape: 0*/
    const re = /(https?:\/\/)?([\w.-]+\.paypal\.[a-z\.]+)(\/\w*)?$/.exec(
      process.env.BASE_URL,
    )
    if (re && re.length >= 3) {
      return `${re[1] || 'https://'}${re[2]}`
    }
  }
  return calculateOrigin({
    stageName: process.env.STAGE,
    port: process.env.PORT,
  })
}

/**
 * @type {Cypress.PluginConfig}
 */
module.exports = (on, config) => {
  // `on` is used to hook into various events Cypress emits
  // `config` is the resolved Cypress config

  // process.env.STAGE is automatically populated by devrunner via the
  // -sn STAGE_NAME, --stage-name STAGE_NAME
  //                  The stage name ex: msmaster (default: msmaster)
  // https://engineering.paypalcorp.com/confluence/pages/viewpage.action?pageId=243600692#PointofSale-82021761
  config.env.STAGE = process.env.STAGE

  // PORT can be set dynamically during our Jenkins builds
  config.env.PORT = process.env.PORT ? process.env.PORT : 8000
  const { requestURI } = shush(
    path.resolve(__dirname, '..', '..', 'config', 'config.json'),
  )

  // Earlier we set baseURL in a support file like
  // "baseUrl": "http://localhost.paypal.com:8000/sampleapp",
  // But this lead to issues with cypress spinning up twice
  // The cypress team suggests to set baseURL in plugins file
  // since this gets read only once at startup
  // https://github.com/cypress-io/cypress/issues/2777#issuecomment-671354102
  config.baseUrl = `${getOrigin()}${requestURI}`

  if (shouldInstrumentCode) {
    require('@cypress/code-coverage/task')(on, config)
  }
  require('@paypalcorp/testframeworkclient/cypress').plugin(on, config)
  return config
}
