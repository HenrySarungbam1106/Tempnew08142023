import { getEvaluations } from '../../../lib/api/evaluations'
import evaluationAPI from '../../api/v1/evaluations.page'

jest.mock('../../../lib/api/evaluations', () => ({
  getEvaluations: jest.fn(),
}))

describe('get evaluations API tests', () => {
  test('success scenario', async () => {
    getEvaluations.mockImplementation(() => ({
      body: {
        success: true,
      },
      statusCode: 202,
    }))

    const jsonSpy = jest.fn()

    await evaluationAPI(
      getReq({
        method: 'POST',
      }),
      getRes({
        status: () => ({ json: jsonSpy }),
      }),
    )

    expect(jsonSpy).toHaveBeenCalledTimes(1)
    expect(jsonSpy).toHaveBeenCalledWith({
      success: true,
    })
  })

  function getReq(overrides) {
    return { ...overrides }
  }
  function getRes(overrides) {
    return {
      json: () => {},
      ...overrides,
    }
  }
})
