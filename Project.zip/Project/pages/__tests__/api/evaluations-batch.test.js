import { getEvaluationsBatch } from '../../../lib/api/evaluations-batch'
import evaluationBatchAPI from '../../api/v1/evaluations-batch.page'

jest.mock('../../../lib/api/evaluations-batch', () => ({
  getEvaluationsBatch: jest.fn(),
}))

describe('get evaluations batch API tests', () => {
  test('success scenario', async () => {
    getEvaluationsBatch.mockImplementation(() => ({
      body: {
        success: true,
      },
      statusCode: 202,
    }))

    const jsonSpy = jest.fn()

    await evaluationBatchAPI(
      getReq({
        method: 'POST',
      }),
      getRes({
        status: () => ({ json: jsonSpy }),
      }),
    )

    expect(jsonSpy).toHaveBeenCalledTimes(1)
    expect(jsonSpy).toHaveBeenCalledWith({
      success: true,
    })
  })

  function getReq(overrides) {
    return { ...overrides }
  }
  function getRes(overrides) {
    return {
      json: () => {},
      ...overrides,
    }
  }
})
