import extendSession from '../../../pages/api/v1/extend-session.page'

describe('extend session API tests', () => {
  test('success scenario', async () => {
    const sendSpy = jest.fn()

    await extendSession(
      getReq({
        method: 'GET',
      }),
      getRes({
        status: () => ({ send: sendSpy }),
      }),
    )

    expect(sendSpy).toHaveBeenCalledTimes(1)
    expect(sendSpy).toHaveBeenCalledWith('OK')
  })

  function getReq(overrides) {
    return { ...overrides }
  }
  function getRes(overrides) {
    return {
      json: () => {},
      ...overrides,
    }
  }
})
