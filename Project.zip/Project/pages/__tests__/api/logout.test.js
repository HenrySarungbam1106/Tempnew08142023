import logout from '../../api/v1/logout.page'

describe('logout page test', () => {
  test('should log user out and redirect', () => {
    const logoutspy = jest.fn()
    const redirectspy = jest.fn()

    logout(
      getReq({
        method: 'POST',
        app: { kraken: { get: () => 'test' } },
        logout: logoutspy,
      }),
      getRes({
        redirect: redirectspy,
      }),
    )

    expect(logoutspy).toHaveBeenCalledTimes(1)
    expect(logoutspy).toHaveBeenCalledWith()

    expect(redirectspy).toHaveBeenCalledTimes(1)
    expect(redirectspy).toHaveBeenCalledWith('test/login')
  })

  function getReq(overrides) {
    return { ...overrides }
  }
  function getRes(overrides) {
    return {
      ...overrides,
    }
  }
})
