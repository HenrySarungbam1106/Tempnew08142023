import {
  fireEvent,
  render,
  screen,
} from '../../components/test/client-test-utils'
import Index from '../index.page'
import TestContext from '../../components//test/context'
import '../../components/test/jest.setup' //required for hydrating worldready config

describe('render index page', () => {
  test('should render index page', async () => {
    render(
      <TestContext>
        <Index />
      </TestContext>,
    )

    const title = await screen.findByText(/Migration Readiness Search/i)
    const accountLabel = screen.getByLabelText(/Account Number or Payer ID/i)
    const migrateFromLabel = screen.getByLabelText(/Migrate From/i)
    const migrateToLabel = screen.getByLabelText(/Migrate To/i)

    const individualTab = screen.getByRole('tab', {
      name: /individual account/i,
    })
    const batchTab = screen.getByRole('tab', { name: /batch upload/i })

    expect(title).toBeInTheDocument()
    expect(individualTab).toBeInTheDocument()
    expect(batchTab).toBeInTheDocument()
    expect(migrateFromLabel).toBeInTheDocument()
    expect(migrateToLabel).toBeInTheDocument()
    expect(accountLabel).toBeInTheDocument()

    fireEvent.click(batchTab)

    const uploadText = await screen.findByText(
      'Upload a CSV file containing account numbers or payer IDs',
    )

    expect(uploadText).toBeInTheDocument()
  })
})
