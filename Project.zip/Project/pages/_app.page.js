import React from 'react'
import '../styles/globals.css'
import Layout from '../components/layout'
import { CacheProvider, ThemeProvider } from '@emotion/react'
import { PAYPAL_THEME } from '@paypalcorp/pp-react'
import createCache from '@emotion/cache'
import { FormContextProvider } from '../context/form-context'
import { ServerContextProvider } from '../context/server-context'

const myCache = createCache({
  key: 'merchantmigration',
  prepend: true,
})

function MyApp({ Component, pageProps }) {
  return (
    <CacheProvider value={myCache}>
      <ThemeProvider theme={PAYPAL_THEME}>
        <ServerContextProvider value={pageProps.serverData ?? {}}>
          <FormContextProvider>
            <Layout {...pageProps}>
              <Component {...pageProps} />
            </Layout>
          </FormContextProvider>
        </ServerContextProvider>
      </ThemeProvider>
    </CacheProvider>
  )
}

export default MyApp
