import React from 'react'
import assert from 'assert'
import Error from 'next/error'
import { processError } from '@paypalcorp/paypalize-nextjs'

function ErrorPage({ statusCode }) {
  assert(
    statusCode,
    'ErrorPage render should not be called if response is sent',
  )
  // Fallback: Next.js should not call this if the response is already sent.
  return <Error statusCode={statusCode} />
  // return ( <></> )
}

// we can check process.env.NEXT_PHASE === 'phase-production-build' (PHASE_PRODUCTION_BUILD)
const isBuild = process.env.NEXT_PHASE === 'phase-production-build'

// checks whether the response object is dummy. It is typically dummy during build
const isValidResponse = (res) => res && typeof res.on === 'function'

// getInitialProps is isomorphic and it will also run on the client side.
// We can't use getServerSideProps here. The error object is only part of context sent to getInitialProps, and that probably is intentional
ErrorPage.getInitialProps = async (ctx) => {
  const { res, err } = ctx

  // processError if running on the server, and the response object is available.
  const errorProcessed =
    !isBuild && isValidResponse(res) && (await processError(ctx))

  // Next.js has logic to not invoke render document if the response is already finished
  // https://github.com/vercel/next.js/blob/3096a772fb1ec088a0c87b08cd259a5d8fe310a6/packages/next/next-server/server/render.tsx#L482
  const statusCode = (res && res.statusCode) || (err && err.statusCode) || 404
  const serverData = res && res.locals && res.locals.serverData
  return { statusCode, serverData, errorProcessed }
}

export default ErrorPage
