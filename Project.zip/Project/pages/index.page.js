import React from 'react'
import {
  getServerSidePropsGenerator,
  getServerSidePropsWrapped,
} from '../lib/client/utils'
import dynamic from 'next/dynamic'

const Landing = dynamic(() => import('../components/landing/landing'), {
  ssr: false,
})

export default function Home(pageProps) {
  return <Landing {...pageProps} />
}

const serverSidePropsFn = getServerSidePropsWrapped(
  getServerSidePropsGenerator('index'),
)
export { serverSidePropsFn as getServerSideProps }
