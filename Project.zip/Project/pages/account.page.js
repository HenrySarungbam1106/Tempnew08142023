import React from 'react'
import {
  getServerSidePropsGenerator,
  getServerSidePropsWrapped,
} from '../lib/client/utils'
import dynamic from 'next/dynamic'

const MigrationDetails = dynamic(
  () => import('../components/migration-details/migration-details'),
  {
    ssr: false,
  },
)

export default function Home(pageProps) {
  return <MigrationDetails {...pageProps} />
}

const serverSidePropsFn = getServerSidePropsWrapped(
  getServerSidePropsGenerator('index'),
)
export { serverSidePropsFn as getServerSideProps }
