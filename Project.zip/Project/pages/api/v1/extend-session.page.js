export default function extendSession(_req, res) {
  //calling this route will run the SSO middleware function which will extend the session
  //hence, no other processing is needed here
  res.status(204).send('OK')
  // res.status(200).json({expiry: req.session?.passport?.expiresAfter})
}

//supress nextjs warning about handler not returning a promise
export const config = {
  api: {
    externalResolver: true,
  },
}
