import { shouldInstrumentCode } from '../../../code-coverage-utils'

export default function instrument(_req, res) {
  if (shouldInstrumentCode && global.__coverage__) {
    res.json({ coverage: global.__coverage__ })
  } else {
    res.sendStatus(404)
  }
}
