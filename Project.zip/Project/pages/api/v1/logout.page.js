export default function logout(req, res) {
  console.log(
    'current session expiry: SSO ',
    req.session?.passport?.expiresAfter,
  )
  if (typeof req.logout === 'function') {
    req.logout()
  }
  const requestURI = req.app.kraken.get('requestURI')
  //redirecting to login will regenerate user session
  res.redirect(`${requestURI}/login`)
}

//supress nextjs warning about handler not returning a promise
export const config = {
  api: {
    externalResolver: true,
  },
}
