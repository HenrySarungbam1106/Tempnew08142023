import { getEvaluations } from '../../../lib/api/evaluations'

export default async function evaluationRequest(req, res) {
  if (req.method === 'GET') {
    res.sendStatus(404)
  } else {
    try {
      console.log('Request with body: ', req.body)
      const response = await getEvaluations(req, res)

      if (response.status > 202) {
        req.log('fatal', 'ACCOUNT_RESPONSE_ERROR', {
          code: response.statusCode,
          body: JSON.stringify(response.body),
        })
      }

      res.status(response.statusCode).json(response.body)
    } catch (err) {
      console.log('Error while getting migration details: ', err)
      req.log('fatal', 'ACCOUNT_ERROR', err?.message)
      res.status(500).json({ message: err?.message })
    }
  }
}

//supress nextjs warning about handler not returning a promise
export const config = {
  api: {
    externalResolver: true,
  },
}
